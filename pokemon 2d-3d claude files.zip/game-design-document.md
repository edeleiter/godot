# Pokemon Time Travel — Game Design Document

## Vision Statement

A creature-collecting action RPG where players travel between two eras — a retro 2D pixel-art past and a modern 3D present — each with distinct visual styles, gameplay feel, and creatures to discover. Inspired by Pokemon Legends: Arceus's real-time mechanics and classic Pokemon's charm.

## Core Pillars

### 1. Dual-Era Exploration
- **2D Era (Past):** Top-down pixel art, tile-based movement, nostalgic aesthetic reminiscent of Gen 1-2 Pokemon
- **3D Era (Present):** Third-person open-world, real-time movement, modern lighting and effects inspired by Legends: Arceus
- Each era is a self-contained world with unique regions, creatures, and stories
- Time travel is a deliberate action (not seamless transitions) — player chooses when to jump

### 2. Real-Time Catching (3D Era)
- Creatures roam the overworld with behavioral AI (aggressive, timid, curious)
- Stealth mechanics — crouch, hide in grass, approach from behind
- Throw capture devices directly in the world
- Some creatures require weakening in battle first

### 3. Hybrid Catching (2D Era)
- Classic random encounters OR visible overworld sprites (configurable)
- Turn-based battle initiation, but catching can happen mid-battle
- Homage to original games while still feeling connected to 3D mechanics

### 4. Action-RPG Battles (3D Era)
- Player actively dodges attacks
- Command creatures in real-time with cooldown-based moves
- Agile Style (faster, weaker) and Strong Style (slower, powerful) variants
- Positioning matters — flanking, terrain advantages

### 5. Turn-Based Battles (2D Era)
- Classic Pokemon-style turn order
- Move selection menus
- Simpler but satisfying — comfort food gameplay

### 6. Unified Progression
- Single save file spans both eras
- Party, inventory, currency, and story flags persist across time travel
- Some items era-specific (flavor only — "Ancient Potion" vs "Modern Potion" function identically)
- Completing content in one era can unlock secrets in the other

### 7. Research & Collection
- Creature dex with tasks per species (catch X, defeat Y, see move Z)
- Research ranks unlock perks, story, and new areas
- Encourages varied engagement beyond "catch one of everything"

## Target Experience

The player should feel like they're playing two interconnected games that complement each other. Tired of 3D action combat? Jump to the past for relaxing turn-based gameplay with the same party. Found a mysterious hint in 2D? Travel to the present to explore its 3D manifestation.

## Scope (Learning Project)

### Phase 1: Vertical Slice
- One small area in each era (connected thematically)
- 5-10 creature species with 2D sprites and 3D models
- Basic catching in both eras
- Basic battling in both eras
- Time travel transition working
- Functional save/load

### Phase 2: Core Loop
- Expanded areas
- 20-30 creatures
- Research/dex system
- Basic story beats
- NPC interactions

### Phase 3: Polish
- Full visual effects
- Sound and music
- UI polish
- Performance optimization

## Out of Scope (For Now)
- Multiplayer/trading
- Breeding
- Competitive battle mechanics (EVs, IVs, natures — can add later)
- Procedural generation
- Voice acting
