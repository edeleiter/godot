# Battle System Specification

## Overview

Two distinct battle systems that share core damage/type calculations but differ in execution:
- **2D Era:** Traditional turn-based, menu-driven
- **3D Era:** Real-time action with cooldowns, dodging, and positioning

Both systems use the same `Creature` and `MoveData` classes, ensuring balance consistency.

---

## Shared Battle Core

### Damage Formula
```csharp
public static class DamageCalculator
{
    public static int Calculate(
        Creature attacker,
        Creature defender,
        MoveData move,
        BattleModifiers modifiers = null)
    {
        if (move.Power == 0) return 0; // Status move
        
        // Base damage
        float damage = (2f * attacker.Level / 5f + 2f);
        damage *= move.Power;
        
        // Attack vs Defense
        if (move.Category == MoveCategory.Physical)
            damage *= (float)attacker.Attack / defender.Defense;
        else
            damage *= (float)attacker.SpAttack / defender.SpDefense;
        
        damage = damage / 50f + 2f;
        
        // Modifiers
        damage *= GetTypeEffectiveness(move.Type, defender.Species);
        damage *= GetSTAB(attacker, move);
        damage *= GetRandomModifier(); // 0.85 - 1.0
        damage *= modifiers?.CriticalHit == true ? 1.5f : 1f;
        damage *= modifiers?.WeatherBonus ?? 1f;
        
        return Math.Max(1, (int)damage);
    }
    
    private static float GetSTAB(Creature attacker, MoveData move)
    {
        // Same-Type Attack Bonus
        if (attacker.Species.PrimaryType == move.Type ||
            attacker.Species.SecondaryType == move.Type)
            return 1.5f;
        return 1f;
    }
    
    private static float GetTypeEffectiveness(ElementType moveType, SpeciesData defender)
    {
        float multiplier = TypeChart.GetEffectiveness(moveType, defender.PrimaryType);
        if (defender.SecondaryType.HasValue)
            multiplier *= TypeChart.GetEffectiveness(moveType, defender.SecondaryType.Value);
        return multiplier;
    }
    
    private static float GetRandomModifier()
    {
        return (float)GD.RandRange(0.85, 1.0);
    }
}
```

### Accuracy Check
```csharp
public static bool AccuracyCheck(MoveData move, Creature attacker, Creature defender, int accuracyStage, int evasionStage)
{
    if (move.Accuracy == 0) return true; // Never misses
    
    float stageMultiplier = GetStageMultiplier(accuracyStage - evasionStage);
    float finalAccuracy = move.Accuracy * stageMultiplier;
    
    return GD.Randf() * 100 < finalAccuracy;
}
```

### Status Conditions
```csharp
public enum StatusCondition
{
    None,
    Burn,       // Halves Attack, chip damage
    Paralysis,  // Halves Speed, 25% skip turn
    Poison,     // Chip damage each turn
    BadPoison,  // Escalating chip damage
    Sleep,      // Cannot act, wakes after 1-3 turns
    Freeze,     // Cannot act, 20% thaw chance per turn
    Fainted     // HP = 0
}
```

---

## 2D Era: Turn-Based Battle

### Battle Flow
```
┌─────────────────────────────────────────────────────────┐
│                   BATTLE START                          │
│  - Transition animation                                 │
│  - Load battle scene                                    │
│  - Send out first creatures                             │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│                   TURN START                            │
│  - Check status effects                                 │
│  - Determine turn order (Speed-based)                   │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│               PLAYER ACTION SELECT                      │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐       │
│  │  Fight  │ │   Bag   │ │ Pokemon │ │   Run   │       │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘       │
│                                                         │
│  Fight → Move selection (4 moves + back)                │
│  Bag → Item selection (use on active or party)          │
│  Pokemon → Switch active creature                       │
│  Run → Attempt escape (may fail vs trainers)            │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│               ENEMY ACTION SELECT                       │
│  - AI determines action based on behavior type          │
│  - Aggressive: highest damage move                      │
│  - Smart: type matchups, status moves                   │
│  - Random: weighted random                              │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│                 TURN RESOLUTION                         │
│  1. Priority moves go first                             │
│  2. Higher Speed acts first (tie = coin flip)           │
│  3. Execute move animations                             │
│  4. Apply damage/effects                                │
│  5. Check fainting                                      │
│  6. End-of-turn effects (poison, weather, etc.)         │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│                 BATTLE END CHECK                        │
│  - All enemy fainted → Victory                          │
│  - All player fainted → Defeat                          │
│  - Caught wild creature → Victory                       │
│  - Escaped → End                                        │
│  - Otherwise → Next turn                                │
└─────────────────────────────────────────────────────────┘
```

### Turn Order Calculation
```csharp
public class TurnOrder2D
{
    public List<BattleAction> DetermineTurnOrder(
        BattleAction playerAction,
        BattleAction enemyAction)
    {
        var actions = new List<BattleAction> { playerAction, enemyAction };
        
        // Sort by priority first, then speed
        return actions
            .OrderByDescending(a => a.Priority)
            .ThenByDescending(a => a.Actor.Speed)
            .ThenBy(a => GD.Randi()) // Random tiebreaker
            .ToList();
    }
}
```

### Battle UI Layout (2D)
```
┌────────────────────────────────────────────────────────────┐
│                                                            │
│  ┌──────────────────┐          ┌──────────────────┐       │
│  │ ENEMY CREATURE   │          │   [Enemy Sprite] │       │
│  │ Lv. 25           │          │                  │       │
│  │ ████████░░ HP    │          └──────────────────┘       │
│  └──────────────────┘                                      │
│                                                            │
│         ┌──────────────────┐                               │
│         │  [Player Sprite] │                               │
│         │                  │          ┌──────────────────┐ │
│         └──────────────────┘          │ PIKACHU   Lv. 28 │ │
│                                       │ ██████████ HP    │ │
│                                       │ 58/58            │ │
│                                       └──────────────────┘ │
│ ┌────────────────────────────────────────────────────────┐ │
│ │  What will PIKACHU do?                                 │ │
│ │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │ │
│ │  │  FIGHT   │ │   BAG    │ │ POKEMON  │ │   RUN    │  │ │
│ │  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │ │
│ └────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────┘
```

### BattleManager2D Interface
```csharp
public class BattleManager2D : Node, IBattleSystem
{
    // State
    private BattleState _state;
    private Creature _playerCreature;
    private Creature _enemyCreature;
    private BattleUI2D _ui;
    
    // Events
    public event Action<BattleResult> OnBattleEnd;
    public event Action<string> OnMessage;
    
    public void StartBattle(BattleContext context)
    {
        _state = BattleState.Intro;
        _playerCreature = context.PlayerLead;
        _enemyCreature = context.EnemyLead;
        
        PlayIntroAnimation();
        TransitionTo(BattleState.PlayerTurn);
    }
    
    public async void ExecutePlayerAction(BattleAction action)
    {
        var enemyAction = _ai.DecideAction(_enemyCreature, _playerCreature);
        var turnOrder = DetermineTurnOrder(action, enemyAction);
        
        foreach (var act in turnOrder)
        {
            await ExecuteAction(act);
            if (CheckBattleEnd()) return;
        }
        
        await ProcessEndOfTurn();
        if (!CheckBattleEnd())
            TransitionTo(BattleState.PlayerTurn);
    }
    
    private async Task ExecuteAction(BattleAction action)
    {
        switch (action.Type)
        {
            case ActionType.Move:
                await ExecuteMove(action.Actor, action.Move, action.Target);
                break;
            case ActionType.Switch:
                await ExecuteSwitch(action.Actor, action.SwitchTarget);
                break;
            case ActionType.Item:
                await ExecuteItem(action.Item, action.Target);
                break;
            case ActionType.Run:
                await AttemptEscape();
                break;
        }
    }
}
```

---

## 3D Era: Real-Time Action Battle

### Battle Flow
```
┌─────────────────────────────────────────────────────────┐
│                   BATTLE TRIGGER                        │
│  - Player throws ball and fails, OR                     │
│  - Aggressive creature spots player, OR                 │
│  - Player initiates attack                              │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│               SEAMLESS TRANSITION                       │
│  - No scene change (same world)                         │
│  - Battle music starts                                  │
│  - UI overlay appears                                   │
│  - Other creatures flee or are paused                   │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│                   ACTIVE BATTLE                         │
│                                                         │
│  PLAYER CONTROLS:                                       │
│  - Move freely in battle area                           │
│  - Dodge roll (invincibility frames)                    │
│  - Command creature: select move → execute              │
│  - Switch creature (has cooldown)                       │
│  - Use items (animation lock)                           │
│  - Throw capture device (if wild)                       │
│                                                         │
│  CREATURE AI:                                           │
│  - Auto-positions near enemy                            │
│  - Auto-attacks with basic move if no command           │
│  - Responds to player commands immediately              │
│                                                         │
│  ENEMY CREATURE:                                        │
│  - Uses moves on cooldowns                              │
│  - Targets player OR player's creature                  │
│  - Telegraphed attacks (wind-up animations)             │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│                   BATTLE END                            │
│  - Enemy fainted → rewards, return to exploration       │
│  - Creature caught → add to party, return               │
│  - Player fainted → blackout, respawn at camp           │
│  - Player flees → run animation, no rewards             │
└─────────────────────────────────────────────────────────┘
```

### Agile and Strong Styles
```csharp
public enum MoveStyle
{
    Normal,
    Agile,   // Faster, weaker, may act again sooner
    Strong   // Slower, stronger, longer recovery
}

public class StyleModifiers
{
    public static MoveModifiers GetModifiers(MoveStyle style)
    {
        return style switch
        {
            MoveStyle.Agile => new MoveModifiers
            {
                PowerMultiplier = 0.75f,
                CooldownMultiplier = 0.5f,  // Much faster recovery
                AccuracyBonus = 10,
                PPCost = 2
            },
            MoveStyle.Strong => new MoveModifiers
            {
                PowerMultiplier = 1.5f,
                CooldownMultiplier = 2.0f,  // Much slower recovery
                AccuracyBonus = -10,
                PPCost = 2
            },
            _ => new MoveModifiers
            {
                PowerMultiplier = 1f,
                CooldownMultiplier = 1f,
                AccuracyBonus = 0,
                PPCost = 1
            }
        };
    }
}
```

### Player in Battle (3D)
```csharp
public class BattlePlayer3D : CharacterBody3D
{
    [Export] public float MoveSpeed { get; set; } = 5f;
    [Export] public float DodgeSpeed { get; set; } = 15f;
    [Export] public float DodgeDuration { get; set; } = 0.3f;
    [Export] public float DodgeCooldown { get; set; } = 0.5f;
    [Export] public float InvincibilityDuration { get; set; } = 0.2f;
    
    private bool _isDodging;
    private bool _isInvincible;
    private float _dodgeCooldownTimer;
    
    public override void _PhysicsProcess(double delta)
    {
        HandleMovement(delta);
        HandleDodge();
        HandleCommands();
    }
    
    private void HandleDodge()
    {
        if (Input.IsActionJustPressed("dodge") && CanDodge())
        {
            StartDodge();
        }
    }
    
    private async void StartDodge()
    {
        _isDodging = true;
        _isInvincible = true;
        
        // Dodge in movement direction (or backward if stationary)
        var direction = GetMovementDirection();
        if (direction == Vector3.Zero)
            direction = -GlobalTransform.Basis.Z;
        
        var tween = CreateTween();
        tween.TweenProperty(this, "velocity", direction * DodgeSpeed, 0.05f);
        
        await ToSignal(GetTree().CreateTimer(InvincibilityDuration), "timeout");
        _isInvincible = false;
        
        await ToSignal(GetTree().CreateTimer(DodgeDuration - InvincibilityDuration), "timeout");
        _isDodging = false;
        _dodgeCooldownTimer = DodgeCooldown;
    }
    
    public bool IsInvincible => _isInvincible;
}
```

### Creature in Battle (3D)
```csharp
public class BattleCreature3D : CharacterBody3D
{
    private Creature _data;
    private BattleCreature3D _target;
    private float[] _moveCooldowns = new float[4];
    
    [Export] public float PreferredDistance { get; set; } = 5f;
    [Export] public float AutoAttackInterval { get; set; } = 3f;
    
    public void CommandMove(int slot, MoveStyle style = MoveStyle.Normal)
    {
        if (_moveCooldowns[slot] > 0) return;
        if (_data.Moves[slot] == null) return;
        
        var move = _data.Moves[slot].Move;
        var modifiers = StyleModifiers.GetModifiers(style);
        
        if (_data.Moves[slot].CurrentPP < modifiers.PPCost) return;
        
        StartMoveExecution(slot, move, modifiers);
    }
    
    private async void StartMoveExecution(int slot, MoveData move, MoveModifiers modifiers)
    {
        // Wind-up (can be interrupted)
        PlayAnimation($"windup_{move.Animation3D}");
        await ToSignal(GetTree().CreateTimer(move.CastTime3D), "timeout");
        
        // Execute
        PlayAnimation($"attack_{move.Animation3D}");
        
        // Deal damage
        if (_target != null && AccuracyCheck(move, _data, _target.Data))
        {
            int damage = DamageCalculator.Calculate(
                _data, _target.Data, move,
                new BattleModifiers { StyleModifier = modifiers }
            );
            _target.TakeDamage(damage);
        }
        
        // Apply cooldown
        _moveCooldowns[slot] = move.Cooldown3D * modifiers.CooldownMultiplier;
        _data.Moves[slot].CurrentPP -= modifiers.PPCost;
    }
}
```

### Battle UI (3D) - HUD Overlay
```
┌────────────────────────────────────────────────────────────┐
│ [ENEMY HP BAR]                                             │
│ Pikachu Lv.25                                              │
│ ████████░░░░░░░░                                           │
│                                                            │
│                    [3D BATTLE SCENE]                       │
│                                                            │
│                                                            │
│                                                            │
│                                                            │
│ ┌─────────────────┐                    ┌─────────────────┐ │
│ │ YOUR POKEMON    │                    │ MOVES           │ │
│ │ Bulbasaur Lv.20 │                    │ [1] Vine Whip ● │ │
│ │ ██████████████  │                    │ [2] Razor Leaf  │ │
│ │ HP: 45/45       │                    │ [3] Sleep Pdr ● │ │
│ │                 │                    │ [4] Solar Beam  │ │
│ └─────────────────┘                    │                 │ │
│                                        │ [A] Agile Style │ │
│ [Y] Items  [B] Pokemon  [X] Run        │ [S] Strong Style│ │
│                                        └─────────────────┘ │
│ [● = On Cooldown]                                          │
└────────────────────────────────────────────────────────────┘
```

### BattleManager3D Interface
```csharp
public class BattleManager3D : Node, IBattleSystem
{
    private BattleState _state;
    private BattlePlayer3D _player;
    private BattleCreature3D _playerCreature;
    private BattleCreature3D _enemyCreature;
    private BattleUI3D _ui;
    
    public event Action<BattleResult> OnBattleEnd;
    
    public void StartBattle(BattleContext context)
    {
        _state = BattleState.Active;
        
        // Spawn battle entities at current positions
        SpawnPlayerCreature(context.PlayerLead);
        SetupEnemyCreature(context.Enemy);
        
        // Start battle music
        AudioManager.PlayBattleMusic();
        
        // Show HUD
        _ui.Show();
    }
    
    public override void _Process(double delta)
    {
        if (_state != BattleState.Active) return;
        
        UpdateCooldowns(delta);
        CheckBattleEnd();
        HandleInput();
    }
    
    private void HandleInput()
    {
        // Move commands (1-4 keys or dpad)
        for (int i = 0; i < 4; i++)
        {
            if (Input.IsActionJustPressed($"move_{i + 1}"))
            {
                var style = GetSelectedStyle();
                _playerCreature.CommandMove(i, style);
            }
        }
    }
    
    private MoveStyle GetSelectedStyle()
    {
        if (Input.IsActionPressed("agile_style")) return MoveStyle.Agile;
        if (Input.IsActionPressed("strong_style")) return MoveStyle.Strong;
        return MoveStyle.Normal;
    }
    
    public void AttemptCatch(Item ball)
    {
        if (_enemyCreature == null) return;
        
        // Pause combat briefly
        _state = BattleState.Catching;
        
        var catchSystem = GetNode<CatchingSystem3D>("/root/CatchingSystem");
        catchSystem.AttemptCatch(_enemyCreature.Data, ball, OnCatchResult);
    }
    
    private void OnCatchResult(bool success, Creature creature)
    {
        if (success)
        {
            EndBattle(new BattleResult { Type = BattleResultType.Caught, CaughtCreature = creature });
        }
        else
        {
            _state = BattleState.Active; // Resume combat
        }
    }
}
```

---

## Wild vs Trainer Battles

### Wild Battles
- Can attempt capture
- Can flee (usually succeeds)
- Single opponent
- No rewards for fleeing

### Trainer Battles (Both Eras)
- Cannot capture
- Cannot flee (blocked)
- Multiple creatures in sequence
- Must defeat all to win
- Money reward on victory

```csharp
public class BattleContext
{
    public BattleType Type { get; set; }          // Wild, Trainer, Boss
    public Creature PlayerLead { get; set; }
    public Creature[] PlayerParty { get; set; }
    
    // Wild battle
    public Creature EnemyLead { get; set; }
    
    // Trainer battle
    public TrainerData Trainer { get; set; }
    public Creature[] TrainerParty { get; set; }
    
    // Rewards
    public int BaseMoney { get; set; }
    public Item[] GuaranteedDrops { get; set; }
    
    public bool CanCatch => Type == BattleType.Wild;
    public bool CanFlee => Type == BattleType.Wild;
}
```

---

## Experience and Leveling

```csharp
public static class ExperienceCalculator
{
    public static int CalculateGain(Creature winner, Creature defeated, bool isTrainerBattle)
    {
        float exp = defeated.Species.BaseExpYield;
        exp *= defeated.Level;
        exp /= 5f;
        
        // Trainer bonus
        if (isTrainerBattle)
            exp *= 1.5f;
        
        // Scaling based on level difference
        float levelRatio = (float)defeated.Level / winner.Level;
        exp *= Math.Clamp(levelRatio, 0.5f, 2f);
        
        return (int)exp;
    }
}
```

### Level-Up Flow
```csharp
public void AddExperience(int amount)
{
    Experience += amount;
    
    while (Experience >= GetExpForLevel(Level + 1) && Level < 100)
    {
        Level++;
        OnLevelUp?.Invoke(this, Level);
        
        // Check for new moves
        if (Species.LevelUpMoves.TryGetValue(Level, out string moveId))
        {
            OnMoveAvailable?.Invoke(this, moveId);
        }
        
        // Check for evolution
        foreach (var evo in Species.Evolutions)
        {
            if (evo.Trigger == EvolutionTrigger.Level && Level >= evo.LevelRequired)
            {
                OnEvolutionReady?.Invoke(this, evo);
            }
        }
    }
}
```
