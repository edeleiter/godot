# Engine Enhancement Opportunities

## Overview

Since you've forked Godot, there are opportunities to add engine-level features that would be difficult or inefficient to implement in GDScript/C#. This document outlines potential enhancements, categorized by impact and complexity.

**Philosophy:** Only enhance the engine when it provides clear benefits over scripting solutions. Avoid bloat.

---

## High Impact, Moderate Complexity

### 1. Seamless 2D/3D Scene Compositing

**Problem:** Godot handles 2D and 3D separately. Transitioning between a 2D world and 3D world requires scene changes, causing loading hitches.

**Enhancement:** Native support for rendering a 2D scene and 3D scene simultaneously with cross-fading/compositing at the renderer level.

**Benefits:**
- Seamless time travel transitions without loading screens
- Could render both eras simultaneously during transition
- "Preview" of other era while in portal

**Implementation Area:** `servers/rendering/` — Add compositor that can blend SubViewport outputs with custom shaders

**Alternative (No Engine Change):** Use SubViewport nodes and shader-based blending. Works, but less efficient.

**Recommendation:** Start with SubViewport approach. Engine enhancement only if transitions feel janky.

---

### 2. Hybrid Pixel-Perfect + 3D Rendering Pipeline

**Problem:** The 2D pixel art era needs pixel-perfect rendering (no sub-pixel movement, integer scaling), while 3D needs smooth rendering. Switching between them requires reconfiguring the viewport.

**Enhancement:** A rendering mode that maintains pixel-perfect 2D while allowing smooth 3D, with automatic switching based on active scene.

**Implementation Area:** `servers/rendering/renderer_viewport.cpp` — Add pixel-perfect mode flag that only affects 2D rendering

**Alternative (No Engine Change):** 
```csharp
// On era switch
if (era == Era.Past)
{
    GetViewport().CanvasItemDefaultTextureFilter = Viewport.DefaultCanvasItemTextureFilter.Nearest;
    GetViewport().Snap2DTransformsToPixel = true;
    GetViewport().Snap2DVerticesToPixel = true;
}
else
{
    GetViewport().CanvasItemDefaultTextureFilter = Viewport.DefaultCanvasItemTextureFilter.Linear;
    GetViewport().Snap2DTransformsToPixel = false;
}
```

**Recommendation:** Script approach is sufficient. No engine change needed.

---

### 3. Native Creature Spawning System

**Problem:** Spawning many creatures in 3D with AI, physics, and rendering is expensive. Object pooling in C# helps but has overhead.

**Enhancement:** Engine-level entity spawning with built-in pooling, LOD, and culling specifically for "creature-like" entities.

**Implementation Area:** New module `modules/creature_system/` or extension of `scene/3d/`

**Benefits:**
- C++ performance for spawn/despawn
- Integrated with physics and rendering culling
- Automatic LOD based on distance

**Alternative (No Engine Change):**
```csharp
public class CreaturePool : Node
{
    private Dictionary<string, Queue<Creature3D>> _pools = new();
    
    public Creature3D Spawn(string speciesId, Vector3 position)
    {
        if (_pools.TryGetValue(speciesId, out var pool) && pool.Count > 0)
        {
            var creature = pool.Dequeue();
            creature.GlobalPosition = position;
            creature.Activate();
            return creature;
        }
        return InstantiateNew(speciesId, position);
    }
    
    public void Despawn(Creature3D creature)
    {
        creature.Deactivate();
        var pool = _pools.GetOrAdd(creature.SpeciesId, _ => new Queue<Creature3D>());
        pool.Enqueue(creature);
    }
}
```

**Recommendation:** Start with C# pooling. Profile first — engine enhancement only if spawning is a proven bottleneck.

---

## Medium Impact, Low Complexity

### 4. Debug Protocol for External Tools (MCP Bridge)

**Problem:** You want Claude to interact with game state for debugging assistance.

**Enhancement:** Built-in debug server that exposes game state via HTTP/WebSocket, queryable by external tools.

**Implementation Area:** New module `modules/debug_server/` with:
- Scene tree inspection
- Node property get/set
- Method invocation
- Frame capture

**Benefits:**
- Always available, not per-project
- C++ performance for serialization
- Could become upstream contribution

**Alternative (No Engine Change):**
```csharp
public partial class DebugServer : Node
{
    private HttpServer _server;
    
    public override void _Ready()
    {
        _server = new HttpServer();
        _server.AddRoute("/entities", GetEntities);
        _server.AddRoute("/camera", GetCamera);
        _server.AddRoute("/spawn", PostSpawn);
        _server.Listen(9999);
    }
    
    private string GetEntities(HttpRequest req)
    {
        var entities = GetTree().GetNodesInGroup("creatures");
        return JsonSerializer.Serialize(entities.Select(e => new {
            e.Name,
            Position = ((Node3D)e).GlobalPosition,
            // ...
        }));
    }
}
```

**Recommendation:** C# implementation is straightforward and sufficient. Only engine-level if you want this for ALL Godot projects.

---

### 5. Built-in Type Effectiveness System

**Problem:** Type effectiveness charts are common in creature games. Currently requires custom implementation.

**Enhancement:** Engine-level `TypeChart` resource with editor support for defining matchups.

**Implementation Area:** `scene/resources/` — New `TypeChart` resource type

**Benefits:**
- Visual editor for type relationships
- Optimized lookup (C++ HashMap)
- Reusable across projects

**Alternative (No Engine Change):**
```csharp
public static class TypeChart
{
    private static readonly Dictionary<(ElementType, ElementType), float> _chart = new()
    {
        { (ElementType.Fire, ElementType.Grass), 2f },
        { (ElementType.Fire, ElementType.Water), 0.5f },
        { (ElementType.Water, ElementType.Fire), 2f },
        // ... etc
    };
    
    public static float GetEffectiveness(ElementType attack, ElementType defend)
    {
        return _chart.GetValueOrDefault((attack, defend), 1f);
    }
}
```

**Recommendation:** C# is fine. Type chart lookups are not performance-critical.

---

## Low Impact / Nice-to-Have

### 6. Shader: Retro CRT Effect (Built-in)

**Problem:** Achieving authentic retro CRT look requires custom shaders.

**Enhancement:** Built-in post-processing effect for CRT simulation (scanlines, curvature, bloom).

**Implementation Area:** `servers/rendering/renderer_rd/effects/`

**Alternative:** Use existing shader from community (plenty available).

**Recommendation:** No engine change. Use community shaders or write your own.

---

### 7. Toon Shading Pipeline

**Problem:** Achieving consistent toon/cel shading for creatures requires careful material setup per model.

**Enhancement:** First-class toon rendering mode for StandardMaterial3D.

**Implementation Area:** `scene/resources/material.cpp` — Add toon shading mode

**Alternative:**
```gdshader
shader_type spatial;

uniform vec3 albedo : source_color;
uniform sampler2D toon_ramp;

void fragment() {
    float NdotL = dot(NORMAL, LIGHT);
    float ramp = texture(toon_ramp, vec2(NdotL * 0.5 + 0.5, 0.0)).r;
    ALBEDO = albedo * ramp;
}
```

**Recommendation:** Custom shader is fine. Toon shading is well-documented for Godot.

---

## Not Recommended for Engine Changes

### ❌ Turn-Based Battle System
Too game-specific. Keep in C#.

### ❌ Creature AI
Better as scriptable behavior trees. Godot's existing navigation and state machine tools suffice.

### ❌ Save System
Platform-agnostic saving is already well-supported. Use C# serialization.

### ❌ UI Theming
Godot's Theme system is already powerful.

---

## Summary: Recommended Engine Work

| Priority | Enhancement | Effort | When to Do It |
|----------|-------------|--------|---------------|
| **1** | Debug Protocol (MCP Bridge) | Medium | If you want Claude debugging across all projects |
| **2** | 2D/3D Compositor | High | Only if SubViewport transitions feel bad |
| **3** | Creature Pooling | Medium | Only if profiling shows spawn bottleneck |

**General Advice:**
1. Build the game first using pure GDScript/C#
2. Profile and identify actual bottlenecks
3. Only then consider engine modifications
4. Document any engine changes thoroughly (for yourself and potential upstream contribution)

---

## Contributing Back to Godot

If you build something useful, consider contributing upstream:
- Debug server would benefit many developers
- 2D/3D compositing is a known pain point
- Follow Godot's contribution guidelines: https://docs.godotengine.org/en/stable/contributing/

Your fork can diverge for game-specific needs, but generic improvements help the community.
