# Time Travel System Specification

## Overview

Time travel is the core mechanic that connects the two eras. Players can move between the 2D past and 3D present while retaining their party, inventory, and progression.

---

## Design Principles

1. **Intentional Travel:** Time travel is a deliberate player action, not automatic
2. **Safe Transitions:** Player cannot time travel during battle or unsafe situations
3. **Persistent State:** All player data carries over; world states remain independent
4. **Thematic Consistency:** Transition effects should feel magical/temporal

---

## Travel Methods

### Primary: Time Portals
Fixed locations in the world where players can travel between eras.

```csharp
public class TimePortal : Node3D // or Node2D for 2D version
{
    [Export] public Era DestinationEra { get; set; }
    [Export] public string DestinationMapPath { get; set; }
    [Export] public Vector3 DestinationPosition { get; set; }
    [Export] public bool RequiresUnlock { get; set; }
    [Export] public string UnlockFlagId { get; set; }
    
    private Area3D _triggerArea;
    
    public override void _Ready()
    {
        _triggerArea = GetNode<Area3D>("TriggerArea");
        _triggerArea.BodyEntered += OnBodyEntered;
    }
    
    private void OnBodyEntered(Node3D body)
    {
        if (body is not Player3D player) return;
        
        if (RequiresUnlock && !PlayerData.Instance.StoryFlags.HasFlag(UnlockFlagId))
        {
            ShowLockedMessage();
            return;
        }
        
        ShowTravelPrompt();
    }
    
    private void ShowTravelPrompt()
    {
        // "Travel to the [Past/Present]? [Yes] [No]"
        var ui = GetNode<TimeTravelUI>("/root/UI/TimeTravelUI");
        ui.ShowPrompt(DestinationEra, OnConfirm, OnCancel);
    }
    
    private void OnConfirm()
    {
        var ttManager = GetNode<TimeTravelManager>("/root/TimeTravel");
        ttManager.TravelTo(DestinationEra, DestinationMapPath, DestinationPosition);
    }
}
```

### Secondary: Time Flute (Key Item)
Allows travel from anywhere (with restrictions).

```csharp
public class TimeFlute : UsableItem
{
    public override bool CanUse(UseContext context)
    {
        // Cannot use during battle
        if (GameManager.Instance.IsInBattle)
        {
            ShowMessage("Cannot use during battle!");
            return false;
        }
        
        // Cannot use in certain story areas
        if (GameManager.Instance.CurrentMap.BlocksTimeTravel)
        {
            ShowMessage("Something is interfering with time travel here...");
            return false;
        }
        
        // Cannot use if any party member is fainted
        if (PlayerData.Instance.Party.Any(c => c.Status == StatusCondition.Fainted))
        {
            ShowMessage("Your party must be healthy to time travel!");
            return false;
        }
        
        return true;
    }
    
    public override void Use(UseContext context)
    {
        var ui = GetNode<TimeTravelUI>("/root/UI/TimeTravelUI");
        ui.ShowDestinationSelect(OnDestinationSelected);
    }
    
    private void OnDestinationSelected(Era era, string mapPath, Vector3 position)
    {
        var ttManager = GetNode<TimeTravelManager>("/root/TimeTravel");
        ttManager.TravelTo(era, mapPath, position);
    }
}
```

---

## Time Travel Manager

The core orchestrator for era transitions.

```csharp
public partial class TimeTravelManager : Node
{
    public Era CurrentEra { get; private set; }
    
    // Signals
    [Signal] public delegate void TimeTravelStartedEventHandler(Era from, Era to);
    [Signal] public delegate void TimeTravelCompletedEventHandler(Era newEra);
    [Signal] public delegate void TimeTravelFailedEventHandler(string reason);
    
    // State tracking
    private Dictionary<Era, EraState> _eraStates = new();
    
    public override void _Ready()
    {
        // Initialize era states
        _eraStates[Era.Past] = new EraState();
        _eraStates[Era.Present] = new EraState();
    }
    
    /// <summary>
    /// Main entry point for time travel
    /// </summary>
    public async void TravelTo(Era destination, string mapPath = null, Vector3? position = null)
    {
        if (destination == CurrentEra)
        {
            GD.PrintErr("Already in this era");
            return;
        }
        
        // Validation
        if (!CanTravel(out string reason))
        {
            EmitSignal(SignalName.TimeTravelFailed, reason);
            return;
        }
        
        EmitSignal(SignalName.TimeTravelStarted, CurrentEra, destination);
        
        // Save current era state
        SaveCurrentEraState();
        
        // Play transition effect
        await PlayTransitionEffect(CurrentEra, destination);
        
        // Determine destination
        mapPath ??= GetDefaultMap(destination);
        position ??= GetDefaultPosition(destination);
        
        // Load new era
        await LoadEra(destination, mapPath, position.Value);
        
        // Update current era
        CurrentEra = destination;
        
        // Apply UI theme
        ApplyEraTheme(destination);
        
        // Complete
        EmitSignal(SignalName.TimeTravelCompleted, destination);
        
        // Autosave
        SaveSystem.Instance.AutoSave("time_travel");
    }
    
    private bool CanTravel(out string reason)
    {
        reason = null;
        
        if (GameManager.Instance.IsInBattle)
        {
            reason = "Cannot time travel during battle";
            return false;
        }
        
        if (GameManager.Instance.IsInCutscene)
        {
            reason = "Cannot time travel during cutscene";
            return false;
        }
        
        if (GameManager.Instance.CurrentMap?.BlocksTimeTravel == true)
        {
            reason = "Time travel is blocked in this area";
            return false;
        }
        
        return true;
    }
    
    private void SaveCurrentEraState()
    {
        var state = _eraStates[CurrentEra];
        state.LastMapPath = GameManager.Instance.CurrentMapPath;
        state.LastPosition = GameManager.Instance.PlayerPosition;
        state.LastRotation = GameManager.Instance.PlayerRotation;
    }
    
    private string GetDefaultMap(Era era)
    {
        // Return last visited map in that era, or starting area
        if (_eraStates[era].LastMapPath != null)
            return _eraStates[era].LastMapPath;
        
        return era switch
        {
            Era.Past => "res://World2D/Scenes/Maps/StartingVillage.tscn",
            Era.Present => "res://World3D/Scenes/Maps/StartingArea.tscn",
            _ => throw new ArgumentException($"Unknown era: {era}")
        };
    }
    
    private Vector3 GetDefaultPosition(Era era)
    {
        if (_eraStates[era].LastPosition != Vector3.Zero)
            return _eraStates[era].LastPosition;
        
        // Return spawn point of starting area
        return era switch
        {
            Era.Past => new Vector3(8, 8, 0), // Tile coordinates for 2D
            Era.Present => new Vector3(0, 0, 10),
            _ => Vector3.Zero
        };
    }
    
    private async Task LoadEra(Era era, string mapPath, Vector3 position)
    {
        // Use Godot's scene changing
        var game = GetNode<GameManager>("/root/Game");
        await game.ChangeSceneAsync(mapPath);
        
        // Position player
        await ToSignal(GetTree(), "process_frame"); // Wait one frame
        game.SetPlayerPosition(position);
    }
    
    private void ApplyEraTheme(Era era)
    {
        var uiManager = GetNode<UIManager>("/root/UI");
        
        var theme = era switch
        {
            Era.Past => GD.Load<Theme>("res://UI/Themes/RetroTheme.tres"),
            Era.Present => GD.Load<Theme>("res://UI/Themes/ModernTheme.tres"),
            _ => null
        };
        
        uiManager.ApplyTheme(theme);
    }
}

public class EraState
{
    public string LastMapPath { get; set; }
    public Vector3 LastPosition { get; set; }
    public Vector3 LastRotation { get; set; }
}

public enum Era
{
    Past,    // 2D retro
    Present  // 3D modern
}
```

---

## Transition Effects

The visual/audio experience of time travel.

### Visual Transition
```csharp
public class TimeTravelTransition : CanvasLayer
{
    [Export] public float TransitionDuration { get; set; } = 2f;
    
    private ColorRect _overlay;
    private AnimationPlayer _animator;
    private AudioStreamPlayer _soundPlayer;
    
    public async Task PlayTransition(Era from, Era to)
    {
        Visible = true;
        
        // Phase 1: Current world fades/distorts
        _animator.Play("distort_out");
        _soundPlayer.Stream = GD.Load<AudioStream>("res://Audio/SFX/time_travel_start.ogg");
        _soundPlayer.Play();
        
        await ToSignal(_animator, "animation_finished");
        
        // Phase 2: White flash / time vortex
        _animator.Play("time_vortex");
        _soundPlayer.Stream = GD.Load<AudioStream>("res://Audio/SFX/time_travel_warp.ogg");
        _soundPlayer.Play();
        
        await ToSignal(_animator, "animation_finished");
        
        // Phase 3: New world fades in (called after scene loads)
    }
    
    public async Task FadeInNewEra()
    {
        _animator.Play("fade_in");
        _soundPlayer.Stream = GD.Load<AudioStream>("res://Audio/SFX/time_travel_arrive.ogg");
        _soundPlayer.Play();
        
        await ToSignal(_animator, "animation_finished");
        
        Visible = false;
    }
}
```

### Visual Ideas
- **2D → 3D:** Pixels scatter and reform as polygons
- **3D → 2D:** World flattens, colors become more saturated/limited
- **Both:** Clock motifs, spiraling vortex, chromatic aberration
- **Sound:** Distinct whoosh/warp sounds, era-appropriate music fade

---

## Travel Restrictions

### Areas That Block Time Travel
```csharp
public partial class MapData : Resource
{
    [Export] public string MapId { get; set; }
    [Export] public string DisplayName { get; set; }
    [Export] public Era Era { get; set; }
    
    // Time travel settings
    [Export] public bool BlocksTimeTravel { get; set; }
    [Export] public string BlockedMessage { get; set; } = "Time travel is blocked here.";
    
    // Story-gated time travel
    [Export] public string RequiredFlagToLeave { get; set; }
}
```

### Situations That Block Travel
| Situation | Reason | Player Feedback |
|-----------|--------|-----------------|
| In battle | Safety | "Cannot time travel during battle" |
| In cutscene | Narrative | (no option shown) |
| Party fainted | Gameplay | "Your party must be healthy" |
| Story area | Narrative | "A mysterious force blocks you" |
| Indoor locations | Logic | "Must be outdoors to time travel" |

---

## Linked Locations

Certain locations in each era correspond to each other thematically.

```csharp
public class LinkedLocation : Resource
{
    [Export] public string LocationId { get; set; }
    
    [Export] public string Map2DPath { get; set; }
    [Export] public Vector2 Position2D { get; set; }
    
    [Export] public string Map3DPath { get; set; }
    [Export] public Vector3 Position3D { get; set; }
    
    [Export] public string Description { get; set; }
}

// Example usage
public static class LinkedLocations
{
    public static LinkedLocation[] All = new[]
    {
        new LinkedLocation
        {
            LocationId = "starting_area",
            Map2DPath = "res://World2D/Scenes/Maps/StartingVillage.tscn",
            Position2D = new Vector2(8, 8),
            Map3DPath = "res://World3D/Scenes/Maps/StartingArea.tscn",
            Position3D = new Vector3(0, 0, 10),
            Description = "The village square / town center"
        },
        new LinkedLocation
        {
            LocationId = "ancient_ruins",
            Map2DPath = "res://World2D/Scenes/Maps/SacredTemple.tscn",
            Position2D = new Vector2(16, 32),
            Map3DPath = "res://World3D/Scenes/Maps/TempleRuins.tscn",
            Position3D = new Vector3(50, 5, 100),
            Description = "The temple - intact in past, ruined in present"
        }
    };
}
```

---

## Save/Load Integration

Time travel state is part of the save file.

```csharp
public class TimeTravelSaveData
{
    public Era CurrentEra { get; set; }
    
    public EraSaveData PastState { get; set; }
    public EraSaveData PresentState { get; set; }
    
    // Unlocked fast-travel points
    public List<string> UnlockedPortalsPast { get; set; } = new();
    public List<string> UnlockedPortalsPresent { get; set; } = new();
}

public class EraSaveData
{
    public string LastMapPath { get; set; }
    public Vector3Serializable LastPosition { get; set; }
    public Vector3Serializable LastRotation { get; set; }
    
    // Era-specific world state
    public Dictionary<string, bool> ChestsOpened { get; set; } = new();
    public Dictionary<string, bool> ItemsCollected { get; set; } = new();
    public List<string> DefeatedTrainers { get; set; } = new();
}
```

---

## UI: Time Travel Menu

When using Time Flute or at a portal with multiple destinations.

```
┌────────────────────────────────────────────────────────────┐
│                    TIME TRAVEL                             │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  Current Era: PAST (2D)                                    │
│                                                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  DESTINATION: PRESENT (3D)                           │  │
│  │                                                      │  │
│  │  ● Starting Town         [Visited]                   │  │
│  │  ○ Northern Forest       [Visited]                   │  │
│  │  ○ Coastal Cliffs        [Not Yet Visited]           │  │
│  │  ○ Mountain Pass         [Locked - Need Badge 3]     │  │
│  │                                                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                            │
│  [A] Select    [B] Cancel    [Y] Toggle Era                │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

## Story Integration Ideas

### Parallel Events
- Something happening in the past affects the present
- NPCs in present reference "legends" you witnessed in past
- Solve puzzles across time (plant seed in past → tree in present)

### Era-Exclusive Content
- Certain creatures only appear in one era
- Different gym leaders / trials in each era
- Items that transform when traveling (Ancient Candy ↔ Rare Candy)

### Time Paradox Prevention
- Simple approach: eras are parallel timelines, not causal
- No paradoxes because worlds are independent
- Story can play with this ("some say changing the past changes nothing...")
