# Creature System Specification

## Overview

Creatures are the core collectible entities. A creature has two representations:
1. **Species Definition** — Static data (base stats, types, learnable moves, evolution)
2. **Creature Instance** — Runtime data (individual stats, nickname, experience, current HP)

## Type System

### Elements
```
Normal, Fire, Water, Electric, Grass, Ice, 
Fighting, Poison, Ground, Flying, Psychic, Bug, 
Rock, Ghost, Dragon, Dark, Steel, Fairy
```

### Type Effectiveness Matrix
Standard Pokemon-style effectiveness:
- Super Effective: 2x damage
- Not Very Effective: 0.5x damage  
- Immune: 0x damage
- Neutral: 1x damage

Dual types multiply (e.g., Fire vs Grass/Steel = 2x × 2x = 4x)

## Species Definition

```csharp
// Stored as JSON or Resource files
public class SpeciesData : Resource
{
    [Export] public string Id { get; set; }              // "pikachu"
    [Export] public string DisplayName { get; set; }     // "Pikachu"
    [Export] public int DexNumber { get; set; }          // 25
    
    // Types
    [Export] public ElementType PrimaryType { get; set; }
    [Export] public ElementType? SecondaryType { get; set; }
    
    // Base Stats (Pokemon-style, 1-255 range)
    [Export] public int BaseHp { get; set; }
    [Export] public int BaseAttack { get; set; }
    [Export] public int BaseDefense { get; set; }
    [Export] public int BaseSpAttack { get; set; }
    [Export] public int BaseSpDefense { get; set; }
    [Export] public int BaseSpeed { get; set; }
    
    // Growth
    [Export] public GrowthRate GrowthRate { get; set; }  // Fast, Medium, Slow, etc.
    [Export] public int BaseExpYield { get; set; }
    [Export] public int CatchRate { get; set; }          // 1-255
    
    // Moves
    [Export] public Dictionary<int, string> LevelUpMoves { get; set; }  // level → move_id
    [Export] public string[] TmMoves { get; set; }
    [Export] public string[] EggMoves { get; set; }
    
    // Evolution
    [Export] public EvolutionData[] Evolutions { get; set; }
    
    // Visuals (references, not embedded)
    [Export] public string Sprite2DPath { get; set; }    // "res://World2D/Resources/Sprites/pikachu.png"
    [Export] public string Model3DPath { get; set; }     // "res://World3D/Resources/Models/pikachu.glb"
    [Export] public string IconPath { get; set; }        // Menu icon
    [Export] public string CryAudioPath { get; set; }
    
    // Overworld Behavior (3D era)
    [Export] public CreatureBehavior DefaultBehavior { get; set; }  // Aggressive, Timid, Curious
    [Export] public float DetectionRadius { get; set; }
    [Export] public float FleeSpeed { get; set; }
    [Export] public float AggroSpeed { get; set; }
    
    // Dex
    [Export] public string Category { get; set; }         // "Mouse Pokémon"
    [Export] public float HeightMeters { get; set; }
    [Export] public float WeightKg { get; set; }
    [Export] public string DexEntry2D { get; set; }       // Past era description
    [Export] public string DexEntry3D { get; set; }       // Present era description
}
```

## Evolution Data

```csharp
public class EvolutionData : Resource
{
    [Export] public string TargetSpeciesId { get; set; }
    [Export] public EvolutionTrigger Trigger { get; set; }
    
    // Conditional fields based on trigger
    [Export] public int LevelRequired { get; set; }
    [Export] public string ItemRequired { get; set; }
    [Export] public string MoveRequired { get; set; }
    [Export] public float FriendshipRequired { get; set; }
    [Export] public TimeOfDay TimeRequired { get; set; }
    [Export] public Era EraRequired { get; set; }          // Unique: some evolve only in specific era!
    [Export] public string LocationRequired { get; set; }
}

public enum EvolutionTrigger
{
    Level,
    Item,
    Trade,
    Friendship,
    Move,
    TimeOfDay,
    Era,           // New: evolves only when in 2D or 3D era
    Location
}
```

### Era-Specific Evolution (Unique Feature)
Some creatures evolve differently based on which era they're in:
- Evolving in the 2D era might produce a "retro" form
- Evolving in the 3D era might produce a "modern" form
- Creates collecting incentive across both eras

## Creature Instance

```csharp
public class Creature
{
    // Identity
    public Guid UniqueId { get; }                 // Unique across save file
    public string SpeciesId { get; private set; }
    public string Nickname { get; set; }
    public string OriginalTrainer { get; set; }
    public Era CaughtInEra { get; set; }          // Where this creature was caught
    public DateTime CaughtAt { get; set; }
    
    // Stats
    public int Level { get; private set; }
    public int Experience { get; private set; }
    public int CurrentHp { get; set; }
    
    // Individual Values (0-31, determined at spawn/catch)
    public StatBlock IVs { get; }
    
    // Effort Values (0-252 per stat, 510 total cap)
    public StatBlock EVs { get; }
    
    // Moves (max 4)
    public MoveSlot[] Moves { get; } = new MoveSlot[4];
    
    // Status
    public StatusCondition Status { get; set; }   // Burn, Poison, Paralysis, etc.
    public bool IsShiny { get; }
    
    // Calculated Stats
    public int MaxHp => CalculateStat(StatType.Hp);
    public int Attack => CalculateStat(StatType.Attack);
    public int Defense => CalculateStat(StatType.Defense);
    public int SpAttack => CalculateStat(StatType.SpAttack);
    public int SpDefense => CalculateStat(StatType.SpDefense);
    public int Speed => CalculateStat(StatType.Speed);
    
    // Species data reference
    public SpeciesData Species => Database.GetSpecies(SpeciesId);
    
    // Methods
    public void AddExperience(int amount);
    public bool CanEvolve(EvolutionContext context);
    public Creature Evolve(EvolutionData evolution);
    public void LearnMove(string moveId, int slot);
    public void Heal();
    public void TakeDamage(int amount);
}

public class StatBlock
{
    public int Hp { get; set; }
    public int Attack { get; set; }
    public int Defense { get; set; }
    public int SpAttack { get; set; }
    public int SpDefense { get; set; }
    public int Speed { get; set; }
}

public class MoveSlot
{
    public string MoveId { get; set; }
    public int CurrentPP { get; set; }
    public int PPUps { get; set; }      // 0-3, increases max PP
    
    public MoveData Move => Database.GetMove(MoveId);
    public int MaxPP => Move.BasePP + (Move.BasePP * PPUps / 5);
}
```

## Stat Calculation Formula

Standard Pokemon formula:
```csharp
private int CalculateStat(StatType stat)
{
    var baseStat = stat switch
    {
        StatType.Hp => Species.BaseHp,
        StatType.Attack => Species.BaseAttack,
        // ... etc
    };
    
    var iv = IVs.GetStat(stat);
    var ev = EVs.GetStat(stat);
    
    if (stat == StatType.Hp)
    {
        // HP formula
        return ((2 * baseStat + iv + ev / 4) * Level / 100) + Level + 10;
    }
    else
    {
        // Other stats formula (nature modifier would go here)
        return ((2 * baseStat + iv + ev / 4) * Level / 100) + 5;
    }
}
```

## Move Data

```csharp
public class MoveData : Resource
{
    [Export] public string Id { get; set; }
    [Export] public string DisplayName { get; set; }
    [Export] public ElementType Type { get; set; }
    [Export] public MoveCategory Category { get; set; }  // Physical, Special, Status
    
    [Export] public int Power { get; set; }              // 0 for status moves
    [Export] public int Accuracy { get; set; }           // 0-100, 0 = never misses
    [Export] public int BasePP { get; set; }
    [Export] public int Priority { get; set; }           // -7 to +7
    
    [Export] public MoveTarget Target { get; set; }      // Single, AllEnemies, Self, etc.
    [Export] public string[] Effects { get; set; }       // Effect IDs to apply
    
    // 3D Era specific
    [Export] public float Cooldown3D { get; set; }       // Seconds between uses
    [Export] public float CastTime3D { get; set; }       // Windup time
    [Export] public bool CanUseAgileStyle { get; set; }
    [Export] public bool CanUseStrongStyle { get; set; }
    
    // Visuals
    [Export] public string Animation2D { get; set; }
    [Export] public string Animation3D { get; set; }
    [Export] public string SoundEffect { get; set; }
    
    [Export] public string Description { get; set; }
}

public enum MoveCategory { Physical, Special, Status }
public enum MoveTarget { SingleEnemy, AllEnemies, Self, SingleAlly, AllAllies, All }
```

## Creature Spawning

### 2D Era
```csharp
public class SpawnTable2D : Resource
{
    [Export] public string MapId { get; set; }
    [Export] public SpawnEntry2D[] Entries { get; set; }
}

public class SpawnEntry2D : Resource
{
    [Export] public string SpeciesId { get; set; }
    [Export] public int MinLevel { get; set; }
    [Export] public int MaxLevel { get; set; }
    [Export] public float EncounterRate { get; set; }    // Weight for random selection
    [Export] public SpawnMethod2D Method { get; set; }   // Walking, Surfing, Fishing, etc.
    [Export] public TimeOfDay[] ActiveTimes { get; set; }
}
```

### 3D Era
```csharp
public class SpawnTable3D : Resource
{
    [Export] public string MapId { get; set; }
    [Export] public SpawnZone3D[] Zones { get; set; }
}

public class SpawnZone3D : Resource
{
    [Export] public Vector3 Center { get; set; }
    [Export] public float Radius { get; set; }
    [Export] public SpawnEntry3D[] Entries { get; set; }
    [Export] public int MaxConcurrentSpawns { get; set; }
    [Export] public float RespawnInterval { get; set; }
}

public class SpawnEntry3D : Resource
{
    [Export] public string SpeciesId { get; set; }
    [Export] public int MinLevel { get; set; }
    [Export] public int MaxLevel { get; set; }
    [Export] public float SpawnWeight { get; set; }
    [Export] public TimeOfDay[] ActiveTimes { get; set; }
    [Export] public Weather[] ActiveWeather { get; set; }
    [Export] public bool IsAlpha { get; set; }           // Larger, stronger variant
    [Export] public float ShinyOdds { get; set; }        // Override default 1/4096
}
```

## Research/Dex System

```csharp
public class ResearchEntry
{
    public string SpeciesId { get; set; }
    public bool Seen { get; set; }
    public bool Caught { get; set; }
    public int CaughtInEra2D { get; set; }
    public int CaughtInEra3D { get; set; }
    public int ResearchLevel { get; set; }       // 0-10
    public int ResearchPoints { get; set; }
    
    // Task completion tracking
    public Dictionary<string, int> TaskProgress { get; set; }
}

public class ResearchTask
{
    public string Id { get; set; }               // "catch_5", "see_move_thunderbolt"
    public string Description { get; set; }      // "Catch 5 Pikachu"
    public int[] Thresholds { get; set; }        // [1, 3, 5, 10, 20]
    public int PointsPerThreshold { get; set; }  // Points awarded at each threshold
}
```

### Research Tasks Per Species
- Number caught (total, per era)
- Number defeated
- Number caught without being spotted (3D)
- Times you've seen it use [specific move]
- Evolved specimens caught
- Alpha specimens caught
- Heavy/Light specimens caught

Research level 10 = "Perfect" entry, unlocks special rewards.

## File Format Examples

### Species JSON
```json
{
  "id": "pikachu",
  "display_name": "Pikachu",
  "dex_number": 25,
  "primary_type": "Electric",
  "secondary_type": null,
  
  "base_stats": {
    "hp": 35,
    "attack": 55,
    "defense": 40,
    "sp_attack": 50,
    "sp_defense": 50,
    "speed": 90
  },
  
  "growth_rate": "MediumFast",
  "catch_rate": 190,
  "base_exp_yield": 112,
  
  "level_up_moves": {
    "1": "thunder_shock",
    "4": "tail_whip",
    "8": "quick_attack",
    "12": "electro_ball"
  },
  
  "evolutions": [
    {
      "target": "raichu",
      "trigger": "Item",
      "item_required": "thunder_stone"
    },
    {
      "target": "raichu_alolan",
      "trigger": "Item",
      "item_required": "thunder_stone",
      "era_required": "Past"
    }
  ],
  
  "behavior": {
    "default": "Timid",
    "detection_radius": 15.0,
    "flee_speed": 8.0
  },
  
  "visuals": {
    "sprite_2d": "res://World2D/Resources/Sprites/Creatures/pikachu.png",
    "model_3d": "res://World3D/Resources/Models/Creatures/pikachu.glb",
    "icon": "res://UI/Icons/Creatures/pikachu.png"
  }
}
```
