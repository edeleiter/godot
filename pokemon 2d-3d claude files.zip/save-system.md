# Save System Specification

## Overview

A unified save system that persists player state across both eras. Supports multiple save slots, autosave, and corruption recovery.

---

## Save Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        SaveSystem                                │
│                                                                  │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │
│  │  SaveSlot   │    │  SaveSlot   │    │  SaveSlot   │         │
│  │    #1       │    │    #2       │    │    #3       │         │
│  └─────────────┘    └─────────────┘    └─────────────┘         │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   AutoSave Slot                          │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Save Data Structure

```csharp
[Serializable]
public class SaveData
{
    // Metadata
    public string Version { get; set; } = "1.0.0";
    public DateTime SavedAt { get; set; }
    public TimeSpan PlayTime { get; set; }
    public string PlayerName { get; set; }
    
    // Current location
    public Era CurrentEra { get; set; }
    public string CurrentMapPath { get; set; }
    public SerializableVector3 PlayerPosition { get; set; }
    public SerializableVector3 PlayerRotation { get; set; }
    
    // Player state
    public List<CreatureSaveData> Party { get; set; } = new();
    public List<CreatureSaveData> Box { get; set; } = new();
    public BagSaveData Bag { get; set; } = new();
    public int Money { get; set; }
    
    // Progression
    public PokedexSaveData Pokedex { get; set; } = new();
    public Dictionary<string, bool> StoryFlags { get; set; } = new();
    public List<string> Badges { get; set; } = new();
    
    // Time travel state
    public TimeTravelSaveData TimeTravel { get; set; } = new();
    
    // Per-era world state
    public WorldStateSaveData World2D { get; set; } = new();
    public WorldStateSaveData World3D { get; set; } = new();
    
    // Settings (optional to include in save)
    public SettingsSaveData Settings { get; set; }
}
```

### Sub-Data Structures

```csharp
[Serializable]
public class CreatureSaveData
{
    public Guid UniqueId { get; set; }
    public string SpeciesId { get; set; }
    public string Nickname { get; set; }
    
    public int Level { get; set; }
    public int Experience { get; set; }
    public int CurrentHp { get; set; }
    
    public StatBlockSaveData IVs { get; set; }
    public StatBlockSaveData EVs { get; set; }
    
    public MoveSaveData[] Moves { get; set; } = new MoveSaveData[4];
    
    public StatusCondition Status { get; set; }
    public bool IsShiny { get; set; }
    
    public string OriginalTrainer { get; set; }
    public Era CaughtInEra { get; set; }
    public DateTime CaughtAt { get; set; }
}

[Serializable]
public class MoveSaveData
{
    public string MoveId { get; set; }
    public int CurrentPP { get; set; }
    public int PPUps { get; set; }
}

[Serializable]
public class BagSaveData
{
    public Dictionary<string, int> Items { get; set; } = new();
    public Dictionary<string, int> KeyItems { get; set; } = new();
    public Dictionary<string, int> PokeBalls { get; set; } = new();
    public Dictionary<string, int> Medicine { get; set; } = new();
    public Dictionary<string, int> TMs { get; set; } = new();
}

[Serializable]
public class PokedexSaveData
{
    public Dictionary<string, PokedexEntrySaveData> Entries { get; set; } = new();
}

[Serializable]
public class PokedexEntrySaveData
{
    public bool Seen { get; set; }
    public bool Caught { get; set; }
    public int CaughtCount2D { get; set; }
    public int CaughtCount3D { get; set; }
    public int ResearchLevel { get; set; }
    public int ResearchPoints { get; set; }
    public Dictionary<string, int> TaskProgress { get; set; } = new();
}

[Serializable]
public class WorldStateSaveData
{
    public HashSet<string> ChestsOpened { get; set; } = new();
    public HashSet<string> ItemsCollected { get; set; } = new();
    public HashSet<string> TrainersDefeated { get; set; } = new();
    public HashSet<string> PortalsUnlocked { get; set; } = new();
    public Dictionary<string, object> CustomState { get; set; } = new();
}

[Serializable]
public class SerializableVector3
{
    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
    
    public SerializableVector3() { }
    public SerializableVector3(Vector3 v) { X = v.X; Y = v.Y; Z = v.Z; }
    public Vector3 ToVector3() => new(X, Y, Z);
}
```

---

## SaveSystem Implementation

```csharp
public partial class SaveSystem : Node
{
    private const string SAVE_DIR = "user://saves/";
    private const string SAVE_EXTENSION = ".sav";
    private const string BACKUP_EXTENSION = ".bak";
    private const int MAX_SAVE_SLOTS = 3;
    
    public static SaveSystem Instance { get; private set; }
    
    private SaveData _currentData;
    private int _currentSlot = -1;
    private DateTime _sessionStart;
    
    // Signals
    [Signal] public delegate void SaveStartedEventHandler(int slot);
    [Signal] public delegate void SaveCompletedEventHandler(int slot, bool success);
    [Signal] public delegate void LoadStartedEventHandler(int slot);
    [Signal] public delegate void LoadCompletedEventHandler(int slot, bool success);
    
    public override void _Ready()
    {
        Instance = this;
        _sessionStart = DateTime.UtcNow;
        EnsureSaveDirectory();
    }
    
    private void EnsureSaveDirectory()
    {
        var dir = DirAccess.Open("user://");
        if (!dir.DirExists("saves"))
        {
            dir.MakeDir("saves");
        }
    }
    
    // ─────────────────────────────────────────────────────────
    // SAVE OPERATIONS
    // ─────────────────────────────────────────────────────────
    
    public async Task<bool> Save(int slot)
    {
        if (slot < 0 || slot > MAX_SAVE_SLOTS) // slot 0 = autosave
        {
            GD.PrintErr($"Invalid save slot: {slot}");
            return false;
        }
        
        EmitSignal(SignalName.SaveStarted, slot);
        
        try
        {
            // Gather current state
            var data = GatherSaveData();
            
            // Create backup of existing save
            BackupExistingSave(slot);
            
            // Serialize and write
            var path = GetSavePath(slot);
            var json = JsonSerializer.Serialize(data, GetJsonOptions());
            
            // Encrypt if desired
            var bytes = EncryptData(json);
            
            // Write atomically (write to temp, then rename)
            var tempPath = path + ".tmp";
            await File.WriteAllBytesAsync(ProjectSettings.GlobalizePath(tempPath), bytes);
            
            // Rename temp to final
            var dir = DirAccess.Open(SAVE_DIR);
            if (dir.FileExists(GetFileName(slot)))
            {
                dir.Remove(GetFileName(slot));
            }
            dir.Rename(GetFileName(slot) + ".tmp", GetFileName(slot));
            
            _currentSlot = slot;
            
            EmitSignal(SignalName.SaveCompleted, slot, true);
            GD.Print($"Game saved to slot {slot}");
            return true;
        }
        catch (Exception ex)
        {
            GD.PrintErr($"Save failed: {ex.Message}");
            EmitSignal(SignalName.SaveCompleted, slot, false);
            return false;
        }
    }
    
    public void AutoSave(string trigger = "")
    {
        GD.Print($"Autosaving... (trigger: {trigger})");
        _ = Save(0); // Slot 0 is autosave
    }
    
    private SaveData GatherSaveData()
    {
        var player = GetNode<PlayerData>("/root/Player");
        var game = GetNode<GameManager>("/root/Game");
        var timeTravel = GetNode<TimeTravelManager>("/root/TimeTravel");
        
        return new SaveData
        {
            Version = GetCurrentVersion(),
            SavedAt = DateTime.UtcNow,
            PlayTime = (_currentData?.PlayTime ?? TimeSpan.Zero) + (DateTime.UtcNow - _sessionStart),
            PlayerName = player.PlayerName,
            
            CurrentEra = timeTravel.CurrentEra,
            CurrentMapPath = game.CurrentMapPath,
            PlayerPosition = new SerializableVector3(game.PlayerPosition),
            PlayerRotation = new SerializableVector3(game.PlayerRotation),
            
            Party = player.Party.Select(c => c.ToSaveData()).ToList(),
            Box = player.Box.Select(c => c.ToSaveData()).ToList(),
            Bag = player.Bag.ToSaveData(),
            Money = player.Money,
            
            Pokedex = player.Pokedex.ToSaveData(),
            StoryFlags = new Dictionary<string, bool>(player.StoryFlags),
            Badges = new List<string>(player.Badges),
            
            TimeTravel = timeTravel.ToSaveData(),
            
            World2D = game.GetWorldState(Era.Past).ToSaveData(),
            World3D = game.GetWorldState(Era.Present).ToSaveData()
        };
    }
    
    // ─────────────────────────────────────────────────────────
    // LOAD OPERATIONS
    // ─────────────────────────────────────────────────────────
    
    public async Task<bool> Load(int slot)
    {
        EmitSignal(SignalName.LoadStarted, slot);
        
        try
        {
            var path = GetSavePath(slot);
            
            if (!FileAccess.FileExists(path))
            {
                GD.PrintErr($"Save file not found: {path}");
                EmitSignal(SignalName.LoadCompleted, slot, false);
                return false;
            }
            
            // Read and decrypt
            var bytes = await File.ReadAllBytesAsync(ProjectSettings.GlobalizePath(path));
            var json = DecryptData(bytes);
            
            // Deserialize
            var data = JsonSerializer.Deserialize<SaveData>(json, GetJsonOptions());
            
            // Version migration if needed
            data = MigrateIfNeeded(data);
            
            // Apply to game state
            await ApplySaveData(data);
            
            _currentData = data;
            _currentSlot = slot;
            _sessionStart = DateTime.UtcNow;
            
            EmitSignal(SignalName.LoadCompleted, slot, true);
            GD.Print($"Game loaded from slot {slot}");
            return true;
        }
        catch (Exception ex)
        {
            GD.PrintErr($"Load failed: {ex.Message}");
            
            // Try loading backup
            if (await TryLoadBackup(slot))
            {
                EmitSignal(SignalName.LoadCompleted, slot, true);
                return true;
            }
            
            EmitSignal(SignalName.LoadCompleted, slot, false);
            return false;
        }
    }
    
    private async Task ApplySaveData(SaveData data)
    {
        var player = GetNode<PlayerData>("/root/Player");
        var game = GetNode<GameManager>("/root/Game");
        var timeTravel = GetNode<TimeTravelManager>("/root/TimeTravel");
        
        // Apply player data
        player.PlayerName = data.PlayerName;
        player.Money = data.Money;
        player.Party.Clear();
        foreach (var c in data.Party)
            player.Party.Add(Creature.FromSaveData(c));
        player.Box.Clear();
        foreach (var c in data.Box)
            player.Box.Add(Creature.FromSaveData(c));
        player.Bag.FromSaveData(data.Bag);
        player.Pokedex.FromSaveData(data.Pokedex);
        player.StoryFlags = new Dictionary<string, bool>(data.StoryFlags);
        player.Badges = new List<string>(data.Badges);
        
        // Apply world state
        game.SetWorldState(Era.Past, WorldState.FromSaveData(data.World2D));
        game.SetWorldState(Era.Present, WorldState.FromSaveData(data.World3D));
        
        // Apply time travel state
        timeTravel.FromSaveData(data.TimeTravel);
        
        // Load the scene
        await game.ChangeSceneAsync(data.CurrentMapPath);
        game.SetPlayerPosition(data.PlayerPosition.ToVector3());
        game.SetPlayerRotation(data.PlayerRotation.ToVector3());
    }
    
    // ─────────────────────────────────────────────────────────
    // SLOT MANAGEMENT
    // ─────────────────────────────────────────────────────────
    
    public SaveSlotInfo[] GetSlotInfos()
    {
        var infos = new SaveSlotInfo[MAX_SAVE_SLOTS + 1]; // +1 for autosave
        
        for (int i = 0; i <= MAX_SAVE_SLOTS; i++)
        {
            var path = GetSavePath(i);
            
            if (FileAccess.FileExists(path))
            {
                try
                {
                    var bytes = FileAccess.GetFileAsBytes(path);
                    var json = DecryptData(bytes);
                    var data = JsonSerializer.Deserialize<SaveData>(json, GetJsonOptions());
                    
                    infos[i] = new SaveSlotInfo
                    {
                        Slot = i,
                        IsEmpty = false,
                        PlayerName = data.PlayerName,
                        PlayTime = data.PlayTime,
                        SavedAt = data.SavedAt,
                        CurrentEra = data.CurrentEra,
                        PartyCount = data.Party.Count,
                        BadgeCount = data.Badges.Count
                    };
                }
                catch
                {
                    infos[i] = new SaveSlotInfo { Slot = i, IsEmpty = false, IsCorrupted = true };
                }
            }
            else
            {
                infos[i] = new SaveSlotInfo { Slot = i, IsEmpty = true };
            }
        }
        
        return infos;
    }
    
    public bool DeleteSlot(int slot)
    {
        var path = GetSavePath(slot);
        var backupPath = GetBackupPath(slot);
        
        var dir = DirAccess.Open(SAVE_DIR);
        
        if (dir.FileExists(GetFileName(slot)))
            dir.Remove(GetFileName(slot));
        
        if (dir.FileExists(GetBackupFileName(slot)))
            dir.Remove(GetBackupFileName(slot));
        
        return true;
    }
    
    // ─────────────────────────────────────────────────────────
    // BACKUP & RECOVERY
    // ─────────────────────────────────────────────────────────
    
    private void BackupExistingSave(int slot)
    {
        var path = GetSavePath(slot);
        var backupPath = GetBackupPath(slot);
        
        if (FileAccess.FileExists(path))
        {
            var dir = DirAccess.Open(SAVE_DIR);
            if (dir.FileExists(GetBackupFileName(slot)))
                dir.Remove(GetBackupFileName(slot));
            dir.Copy(GetFileName(slot), GetBackupFileName(slot));
        }
    }
    
    private async Task<bool> TryLoadBackup(int slot)
    {
        var backupPath = GetBackupPath(slot);
        
        if (!FileAccess.FileExists(backupPath))
            return false;
        
        GD.Print($"Attempting to load backup for slot {slot}...");
        
        try
        {
            var bytes = await File.ReadAllBytesAsync(ProjectSettings.GlobalizePath(backupPath));
            var json = DecryptData(bytes);
            var data = JsonSerializer.Deserialize<SaveData>(json, GetJsonOptions());
            data = MigrateIfNeeded(data);
            await ApplySaveData(data);
            
            _currentData = data;
            _currentSlot = slot;
            
            GD.Print("Backup loaded successfully");
            return true;
        }
        catch (Exception ex)
        {
            GD.PrintErr($"Backup load failed: {ex.Message}");
            return false;
        }
    }
    
    // ─────────────────────────────────────────────────────────
    // ENCRYPTION (Optional)
    // ─────────────────────────────────────────────────────────
    
    private byte[] EncryptData(string json)
    {
        // Simple XOR "encryption" for casual protection
        // For real security, use AES with proper key management
        var bytes = System.Text.Encoding.UTF8.GetBytes(json);
        var key = GetEncryptionKey();
        
        for (int i = 0; i < bytes.Length; i++)
        {
            bytes[i] ^= key[i % key.Length];
        }
        
        return bytes;
    }
    
    private string DecryptData(byte[] bytes)
    {
        var key = GetEncryptionKey();
        
        for (int i = 0; i < bytes.Length; i++)
        {
            bytes[i] ^= key[i % key.Length];
        }
        
        return System.Text.Encoding.UTF8.GetString(bytes);
    }
    
    private byte[] GetEncryptionKey()
    {
        // In production, use a proper key derivation
        return System.Text.Encoding.UTF8.GetBytes("your-secret-key-here");
    }
    
    // ─────────────────────────────────────────────────────────
    // VERSION MIGRATION
    // ─────────────────────────────────────────────────────────
    
    private SaveData MigrateIfNeeded(SaveData data)
    {
        var currentVersion = new Version(GetCurrentVersion());
        var saveVersion = new Version(data.Version);
        
        if (saveVersion < new Version("1.1.0"))
        {
            // Example migration: add new field with default
            data = MigrateFrom_1_0_0(data);
        }
        
        // Add more migrations as needed
        
        data.Version = GetCurrentVersion();
        return data;
    }
    
    private SaveData MigrateFrom_1_0_0(SaveData data)
    {
        // Example: Research system was added in 1.1.0
        foreach (var entry in data.Pokedex.Entries.Values)
        {
            entry.TaskProgress ??= new Dictionary<string, int>();
        }
        return data;
    }
    
    // ─────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────
    
    private string GetSavePath(int slot) => SAVE_DIR + GetFileName(slot);
    private string GetBackupPath(int slot) => SAVE_DIR + GetBackupFileName(slot);
    private string GetFileName(int slot) => slot == 0 ? $"autosave{SAVE_EXTENSION}" : $"save{slot}{SAVE_EXTENSION}";
    private string GetBackupFileName(int slot) => slot == 0 ? $"autosave{BACKUP_EXTENSION}" : $"save{slot}{BACKUP_EXTENSION}";
    private string GetCurrentVersion() => "1.0.0";
    
    private JsonSerializerOptions GetJsonOptions() => new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };
}

public class SaveSlotInfo
{
    public int Slot { get; set; }
    public bool IsEmpty { get; set; }
    public bool IsCorrupted { get; set; }
    public string PlayerName { get; set; }
    public TimeSpan PlayTime { get; set; }
    public DateTime SavedAt { get; set; }
    public Era CurrentEra { get; set; }
    public int PartyCount { get; set; }
    public int BadgeCount { get; set; }
}
```

---

## Autosave Triggers

```csharp
public partial class AutoSaveManager : Node
{
    [Export] public float IntervalMinutes { get; set; } = 5f;
    
    private float _timer;
    
    public override void _Ready()
    {
        // Subscribe to autosave triggers
        var timeTravel = GetNode<TimeTravelManager>("/root/TimeTravel");
        timeTravel.TimeTravelCompleted += OnTimeTravel;
        
        var game = GetNode<GameManager>("/root/Game");
        game.MapChanged += OnMapChanged;
        
        Events.OnCreatureCaught += OnCreatureCaught;
        Events.OnBattleWon += OnBattleWon;
    }
    
    public override void _Process(double delta)
    {
        _timer += (float)delta;
        
        if (_timer >= IntervalMinutes * 60f)
        {
            _timer = 0f;
            SaveSystem.Instance.AutoSave("interval");
        }
    }
    
    private void OnTimeTravel(Era newEra)
    {
        SaveSystem.Instance.AutoSave("time_travel");
    }
    
    private void OnMapChanged(string newMap)
    {
        SaveSystem.Instance.AutoSave("map_change");
    }
    
    private void OnCreatureCaught(Creature creature)
    {
        SaveSystem.Instance.AutoSave("creature_caught");
    }
    
    private void OnBattleWon(BattleResult result)
    {
        SaveSystem.Instance.AutoSave("battle_won");
    }
}
```

---

## Save/Load UI

```
┌────────────────────────────────────────────────────────────┐
│                      SAVE / LOAD                           │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ AUTOSAVE                                           │   │
│  │ Trainer Red • 12:45:30 playtime                    │   │
│  │ Present Era • 5 Badges • Jan 15, 2024 3:42 PM      │   │
│  │ [Load]                                             │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ SLOT 1                                             │   │
│  │ Trainer Red • 10:30:00 playtime                    │   │
│  │ Past Era • 4 Badges • Jan 14, 2024 8:00 PM         │   │
│  │ [Save] [Load] [Delete]                             │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ SLOT 2                                             │   │
│  │ Empty                                              │   │
│  │ [Save]                                             │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ SLOT 3                                             │   │
│  │ Empty                                              │   │
│  │ [Save]                                             │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  [B] Back                                                  │
│                                                            │
└────────────────────────────────────────────────────────────┘
```
