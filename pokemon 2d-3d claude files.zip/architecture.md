# Technical Architecture

## Technology Stack

| Component | Choice | Rationale |
|-----------|--------|-----------|
| Engine | Godot 4.x (.NET) | Open source, 2D+3D capable, C# support, forkable |
| Language | C# | Strong typing, transferable skills, better tooling |
| IDE | VS Code / Rider | First-class C# support, debugging |
| Version Control | Git | Standard, works with any host |

## Project Structure

```
PokemonTimeTravels/
├── project.godot
├── .gitignore
│
├── Core/                           # Era-agnostic shared systems
│   ├── Autoloads/                  # Singleton managers
│   │   ├── GameManager.cs          # Master game state, scene transitions
│   │   ├── PlayerData.cs           # Party, bag, player state
│   │   ├── SaveSystem.cs           # Serialization, save slots
│   │   └── TimeTravelManager.cs    # Era switching logic
│   │
│   ├── Data/                       # Data definitions (readonly)
│   │   ├── Species/                # Creature species definitions
│   │   ├── Moves/                  # Move definitions
│   │   ├── Items/                  # Item definitions
│   │   └── Database.cs             # Central data access
│   │
│   ├── Models/                     # Runtime data structures
│   │   ├── Creature.cs             # Instance of a caught creature
│   │   ├── Move.cs                 # Instance of a learned move
│   │   ├── Item.cs                 # Instance of inventory item
│   │   ├── Party.cs                # Player's active party
│   │   └── Bag.cs                  # Player's inventory
│   │
│   ├── Interfaces/                 # Contracts for cross-era compatibility
│   │   ├── ICreatureRenderer.cs    # Render a creature (2D or 3D)
│   │   ├── IBattleSystem.cs        # Battle interface
│   │   ├── ICatchingSystem.cs      # Catching interface
│   │   └── IWorldMap.cs            # Map/area interface
│   │
│   └── Utilities/                  # Helpers
│       ├── MathExtensions.cs
│       ├── ResourceLoader.cs
│       └── EventBus.cs             # Decoupled event system
│
├── World2D/                        # Retro past era
│   ├── Scenes/
│   │   ├── World2DRoot.tscn        # Entry point for 2D era
│   │   └── Maps/                   # Individual 2D areas
│   │
│   ├── Scripts/
│   │   ├── Player2D.cs             # Top-down player controller
│   │   ├── Creature2D.cs           # Overworld creature (2D)
│   │   ├── Battle2D/               # Turn-based battle system
│   │   │   ├── BattleManager2D.cs
│   │   │   ├── BattleUI2D.cs
│   │   │   └── TurnResolver.cs
│   │   └── Catching2D/             # 2D catching mechanics
│   │
│   ├── Resources/
│   │   ├── Sprites/                # Character/creature sprites
│   │   ├── Tilesets/               # TileMap assets
│   │   └── Audio/                  # Chiptune/retro sounds
│   │
│   └── Shaders/                    # Retro visual effects
│       ├── PixelPerfect.gdshader
│       └── CRTFilter.gdshader      # Optional CRT scanlines
│
├── World3D/                        # Modern present era
│   ├── Scenes/
│   │   ├── World3DRoot.tscn        # Entry point for 3D era
│   │   └── Maps/                   # Individual 3D areas
│   │
│   ├── Scripts/
│   │   ├── Player3D.cs             # Third-person controller
│   │   ├── Creature3D.cs           # Overworld creature (3D)
│   │   ├── CreatureAI/             # Behavioral AI
│   │   │   ├── CreatureBrain.cs
│   │   │   ├── Behaviors/          # Aggressive, Timid, Curious
│   │   │   └── Senses.cs           # Sight, hearing detection
│   │   ├── Battle3D/               # Real-time battle system
│   │   │   ├── BattleManager3D.cs
│   │   │   ├── BattleUI3D.cs
│   │   │   └── ActionQueue.cs
│   │   ├── Catching3D/             # Real-time catching
│   │   │   ├── ThrowSystem.cs
│   │   │   ├── StealthSystem.cs
│   │   │   └── CaptureCalculator.cs
│   │   └── Camera/
│   │       └── ThirdPersonCamera.cs
│   │
│   ├── Resources/
│   │   ├── Models/                 # 3D creature/character models
│   │   ├── Textures/
│   │   ├── Materials/
│   │   └── Audio/                  # Orchestral/modern sounds
│   │
│   └── Shaders/
│       ├── ToonShading.gdshader    # Stylized creature rendering
│       ├── Grass.gdshader          # Interactive grass
│       └── Water.gdshader
│
├── UI/                             # Shared UI (works in both eras)
│   ├── Scenes/
│   │   ├── MainMenu.tscn
│   │   ├── PauseMenu.tscn
│   │   ├── PartyScreen.tscn
│   │   ├── BagScreen.tscn
│   │   ├── CreatureSummary.tscn
│   │   ├── Pokedex.tscn
│   │   └── TimeTravelUI.tscn       # Era selection interface
│   │
│   ├── Scripts/
│   │   ├── UIManager.cs
│   │   ├── PartyScreen.cs
│   │   ├── BagScreen.cs
│   │   └── Components/             # Reusable UI widgets
│   │
│   ├── Themes/
│   │   ├── RetroTheme.tres         # Pixel-art UI for 2D era
│   │   └── ModernTheme.tres        # Sleek UI for 3D era
│   │
│   └── Fonts/
│
└── Tests/                          # Unit and integration tests
    ├── Core/
    ├── Battle/
    └── Catching/
```

## Autoload (Singleton) Architecture

Godot's Autoload system provides globally accessible managers. Register in Project Settings → Autoload:

| Name | Script | Purpose |
|------|--------|---------|
| `Game` | `Core/Autoloads/GameManager.cs` | Scene transitions, game state machine |
| `Player` | `Core/Autoloads/PlayerData.cs` | Party, bag, currencies, flags |
| `Save` | `Core/Autoloads/SaveSystem.cs` | Save/load, slot management |
| `TimeTravel` | `Core/Autoloads/TimeTravelManager.cs` | Era switching |
| `Events` | `Core/Utilities/EventBus.cs` | Global event pub/sub |

## Key Interfaces

### ICreatureRenderer
```csharp
public interface ICreatureRenderer
{
    void LoadCreature(Creature creature);
    void PlayAnimation(string animationName);
    void SetVisibility(bool visible);
    Vector3 GetWorldPosition(); // 2D returns (x, y, 0)
}
```

### IBattleSystem
```csharp
public interface IBattleSystem
{
    void StartBattle(BattleContext context);
    void EndBattle(BattleResult result);
    void ExecuteMove(Creature user, Move move, Creature target);
    event Action<BattleResult> OnBattleEnd;
}
```

### ICatchingSystem
```csharp
public interface ICatchingSystem
{
    void AttemptCatch(Creature target, Item ball);
    float CalculateCatchRate(Creature target, Item ball);
    event Action<Creature> OnCatchSuccess;
    event Action<Creature> OnCatchFail;
}
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        PlayerData (Autoload)                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────────────────┐ │
│  │  Party  │  │   Bag   │  │ Currency│  │    Story Flags      │ │
│  └─────────┘  └─────────┘  └─────────┘  └─────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    TimeTravelManager                             │
│                                                                  │
│   CurrentEra: Era.Past | Era.Present                            │
│   TravelTo(Era destination) → triggers scene change             │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌──────────────────────┐        ┌──────────────────────┐
│     World2DRoot      │        │     World3DRoot      │
│                      │        │                      │
│  - Player2D          │        │  - Player3D          │
│  - Map (TileMap)     │        │  - Map (3D terrain)  │
│  - Creatures2D[]     │        │  - Creatures3D[]     │
│  - BattleManager2D   │        │  - BattleManager3D   │
└──────────────────────┘        └──────────────────────┘
```

## Scene Transition Flow

```
1. Player interacts with Time Portal (or menu option)
2. TimeTravelManager.TravelTo(Era.Present) called
3. TimeTravelManager:
   a. Emits OnEraSwitchStart event
   b. Triggers transition effect (fade, warp, etc.)
   c. Calls GameManager.ChangeScene("res://World3D/Scenes/World3DRoot.tscn")
   d. Waits for scene ready
   e. Positions player at designated spawn point
   f. Emits OnEraSwitchComplete event
4. New era is now active, PlayerData unchanged
```

## Save File Format

```json
{
  "version": "1.0.0",
  "playtime_seconds": 3600,
  "current_era": "Present",
  "current_map": "res://World3D/Scenes/Maps/StartingArea.tscn",
  "player_position": { "x": 10.5, "y": 0, "z": 25.3 },
  
  "party": [
    {
      "species_id": "pikachu",
      "nickname": "Sparky",
      "level": 25,
      "current_hp": 58,
      "experience": 12500,
      "moves": ["thunderbolt", "quick_attack", "iron_tail", "thunder_wave"],
      "ivs": { "hp": 28, "atk": 31, ... },
      "evs": { "hp": 0, "atk": 0, ... }
    }
  ],
  
  "bag": {
    "pokeballs": { "pokeball": 20, "greatball": 5 },
    "medicine": { "potion": 10, "super_potion": 3 },
    "key_items": ["time_flute", "region_map"]
  },
  
  "pokedex": {
    "pikachu": { "seen": true, "caught": true, "research_level": 5 },
    "bulbasaur": { "seen": true, "caught": false, "research_level": 1 }
  },
  
  "story_flags": {
    "intro_complete": true,
    "first_catch": true,
    "beat_first_boss": false
  },
  
  "world_state": {
    "2d": {
      "chests_opened": ["map1_chest_01", "map1_chest_02"],
      "npcs_talked": ["oak", "rival"]
    },
    "3d": {
      "outbreaks_cleared": ["area1_outbreak_01"],
      "camps_unlocked": ["base_camp", "north_camp"]
    }
  }
}
```

## Dependency Injection Pattern

For testability, systems receive dependencies through constructors or properties rather than calling Autoloads directly:

```csharp
public class BattleManager3D : Node, IBattleSystem
{
    // Injected or resolved
    private IPlayerData _playerData;
    private IEventBus _events;
    
    public override void _Ready()
    {
        // Resolve from Autoloads if not injected
        _playerData ??= GetNode<IPlayerData>("/root/Player");
        _events ??= GetNode<IEventBus>("/root/Events");
    }
}
```

## Error Handling Strategy

```csharp
// Use Result pattern for operations that can fail
public class Result<T>
{
    public bool IsSuccess { get; }
    public T Value { get; }
    public string Error { get; }
    
    public static Result<T> Success(T value) => new(true, value, null);
    public static Result<T> Failure(string error) => new(false, default, error);
}

// Example usage
public Result<Creature> TryCatch(Creature target, Item ball)
{
    if (target == null)
        return Result<Creature>.Failure("No target creature");
    
    if (!ball.IsCatchingDevice)
        return Result<Creature>.Failure("Item is not a catching device");
    
    // ... catching logic
    return Result<Creature>.Success(caughtCreature);
}
```

## Performance Considerations

| Area | Strategy |
|------|----------|
| Creature spawning | Object pooling, spawn budget per frame |
| 3D rendering | LOD system, occlusion culling, shader LOD |
| 2D rendering | Hybrid viewport for pixel-perfect at any resolution |
| Save/Load | Async operations, autosave on era switch |
| AI updates | Staggered updates, LOD for distant creatures |
