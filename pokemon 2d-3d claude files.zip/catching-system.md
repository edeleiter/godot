# Catching System Specification

## Overview

Capturing creatures differs significantly between eras:
- **2D Era:** Menu-driven, turn-based catching during battle
- **3D Era:** Real-time throwing, stealth bonuses, overworld catching

Both use the same capture rate formula at their core.

---

## Core Capture Formula

Based on the classic Pokemon catch rate formula:

```csharp
public static class CaptureCalculator
{
    /// <summary>
    /// Calculate catch probability (0.0 - 1.0)
    /// </summary>
    public static float CalculateCatchRate(
        Creature target,
        Item ball,
        CatchModifiers modifiers = null)
    {
        modifiers ??= new CatchModifiers();
        
        // Base catch rate from species (1-255)
        int speciesCatchRate = target.Species.CatchRate;
        
        // HP modifier: lower HP = easier catch
        float hpRatio = (float)target.CurrentHp / target.MaxHp;
        float hpModifier = (3f - 2f * hpRatio);
        
        // Ball modifier
        float ballModifier = ball.CatchRateMultiplier;
        
        // Status modifier
        float statusModifier = target.Status switch
        {
            StatusCondition.Sleep => 2.5f,
            StatusCondition.Freeze => 2.5f,
            StatusCondition.Paralysis => 1.5f,
            StatusCondition.Poison => 1.5f,
            StatusCondition.BadPoison => 1.5f,
            StatusCondition.Burn => 1.5f,
            _ => 1f
        };
        
        // Calculate modified catch rate
        float modifiedRate = speciesCatchRate * hpModifier * ballModifier * statusModifier;
        
        // Apply 3D era modifiers
        modifiedRate *= modifiers.BackStrikeBonus;    // 2x if hit from behind
        modifiedRate *= modifiers.StealthBonus;       // 1.5x if undetected
        modifiedRate *= modifiers.HeavyBallBonus;     // Based on weight
        modifiedRate *= modifiers.ResearchBonus;      // Higher research = easier catch
        
        // Convert to probability (max 255)
        float catchProbability = modifiedRate / 255f;
        return Math.Clamp(catchProbability, 0.01f, 1f); // Always 1% minimum chance
    }
    
    /// <summary>
    /// Perform shake checks (4 shakes = caught)
    /// </summary>
    public static CatchResult AttemptCatch(Creature target, Item ball, CatchModifiers modifiers)
    {
        float catchRate = CalculateCatchRate(target, ball, modifiers);
        
        // Need to pass 4 shake checks
        int shakes = 0;
        for (int i = 0; i < 4; i++)
        {
            if (GD.Randf() < catchRate)
                shakes++;
            else
                break;
        }
        
        // Critical catch: skip shake checks (rare)
        bool criticalCatch = GD.Randf() < GetCriticalCatchChance(target);
        if (criticalCatch && shakes >= 1)
            shakes = 4;
        
        return new CatchResult
        {
            Success = shakes == 4,
            ShakeCount = shakes,
            WasCritical = criticalCatch && shakes == 4
        };
    }
    
    private static float GetCriticalCatchChance(Creature target)
    {
        // Based on Pokedex completion
        int caughtCount = PlayerData.Instance.Pokedex.CaughtCount;
        
        if (caughtCount >= 600) return 2.5f / 256f;
        if (caughtCount >= 450) return 2.0f / 256f;
        if (caughtCount >= 300) return 1.5f / 256f;
        if (caughtCount >= 150) return 1.0f / 256f;
        if (caughtCount >= 30) return 0.5f / 256f;
        return 0f;
    }
}

public class CatchModifiers
{
    public float BackStrikeBonus { get; set; } = 1f;
    public float StealthBonus { get; set; } = 1f;
    public float HeavyBallBonus { get; set; } = 1f;
    public float ResearchBonus { get; set; } = 1f;
}

public class CatchResult
{
    public bool Success { get; set; }
    public int ShakeCount { get; set; }  // 0-4
    public bool WasCritical { get; set; }
}
```

---

## Ball Types

```csharp
public class BallData : Resource
{
    [Export] public string Id { get; set; }
    [Export] public string DisplayName { get; set; }
    [Export] public float CatchRateMultiplier { get; set; }
    [Export] public BallCondition SpecialCondition { get; set; }
    
    // Visuals
    [Export] public Texture2D Sprite { get; set; }
    [Export] public PackedScene Model3D { get; set; }
    [Export] public Color TrailColor { get; set; }
}

public enum BallCondition
{
    None,           // Standard ball
    HeavyWeight,    // Heavy Ball: better on heavy creatures
    LightWeight,    // Feather Ball: better on light/flying
    QuickStart,     // Quick Ball: better on first turn
    DuskBonus,      // Dusk Ball: better at night/caves
    NetBonus,       // Net Ball: better on Water/Bug
    RepeatBonus,    // Repeat Ball: better if already caught species
    TimerBonus,     // Timer Ball: better with more turns elapsed
    LevelBased      // Level Ball: better if your level >> target
}
```

### Ball Examples
| Ball | Base Multiplier | Condition |
|------|-----------------|-----------|
| Poke Ball | 1.0x | — |
| Great Ball | 1.5x | — |
| Ultra Ball | 2.0x | — |
| Master Ball | 255x | Always catches |
| Quick Ball | 5.0x → 1.0x | First turn only |
| Dusk Ball | 3.0x | Night or cave |
| Heavy Ball | 0-5x | Based on weight |
| Feather Ball | 2.0x | Lighter, longer throw (3D) |

---

## 2D Era: Turn-Based Catching

### Flow
```
┌─────────────────────────────────────────────────────────┐
│  Player selects BAG → POKE BALLS → [Ball Type]         │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  Animation: Player throws ball                          │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  Animation: Ball hits creature, creature enters ball    │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  Shake animations (0-4 based on CatchResult)            │
│  - Each shake has suspenseful pause                     │
│  - Break-out animation if failed                        │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  SUCCESS: "Gotcha! [Creature] was caught!"              │
│  FAILURE: "[Creature] broke free!" → Battle continues   │
└─────────────────────────────────────────────────────────┘
```

### Implementation
```csharp
public class CatchingSystem2D : Node, ICatchingSystem
{
    [Signal] public delegate void CatchAttemptStartedEventHandler(Creature target, Item ball);
    [Signal] public delegate void ShakeCompletedEventHandler(int shakeNumber);
    [Signal] public delegate void CatchSuccessEventHandler(Creature creature);
    [Signal] public delegate void CatchFailedEventHandler(Creature creature, int shakes);
    
    private BattleManager2D _battleManager;
    private AnimationPlayer _animator;
    
    public async void AttemptCatch(Creature target, Item ball)
    {
        EmitSignal(SignalName.CatchAttemptStarted, target, ball);
        
        // Use ball from bag
        PlayerData.Instance.Bag.RemoveItem(ball.Id, 1);
        
        // Calculate result
        var result = CaptureCalculator.AttemptCatch(target, ball, new CatchModifiers());
        
        // Play throw animation
        await PlayThrowAnimation(ball);
        
        // Play shake animations
        for (int i = 0; i < result.ShakeCount; i++)
        {
            await PlayShakeAnimation(i + 1, result.WasCritical);
            EmitSignal(SignalName.ShakeCompleted, i + 1);
        }
        
        if (result.Success)
        {
            await PlayCatchSuccessAnimation();
            var caughtCreature = FinalizeCatch(target);
            EmitSignal(SignalName.CatchSuccess, caughtCreature);
        }
        else
        {
            await PlayBreakOutAnimation();
            EmitSignal(SignalName.CatchFailed, target, result.ShakeCount);
        }
    }
    
    private Creature FinalizeCatch(Creature wildCreature)
    {
        // Set caught metadata
        wildCreature.OriginalTrainer = PlayerData.Instance.PlayerName;
        wildCreature.CaughtInEra = Era.Past;
        wildCreature.CaughtAt = DateTime.UtcNow;
        
        // Add to party or box
        if (PlayerData.Instance.Party.Count < 6)
        {
            PlayerData.Instance.Party.Add(wildCreature);
        }
        else
        {
            PlayerData.Instance.Box.Add(wildCreature);
        }
        
        // Update Pokedex
        PlayerData.Instance.Pokedex.RegisterCaught(wildCreature.SpeciesId, Era.Past);
        
        return wildCreature;
    }
}
```

---

## 3D Era: Real-Time Catching

### Overworld Catching (Stealth)
The signature Legends: Arceus feature — catch without battling.

```
┌─────────────────────────────────────────────────────────┐
│  Player approaches creature stealthily                  │
│  - Crouch in tall grass                                 │
│  - Stay outside detection radius                        │
│  - Approach from behind for bonus                       │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  Player aims and throws ball                            │
│  - Trajectory arc preview                               │
│  - Account for distance and movement                    │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  Ball travels through air (physics-based)               │
│  - Can miss if creature moves                           │
│  - Hits terrain if blocked                              │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  HIT: Creature enters ball                              │
│  MISS: Ball lands, creature may flee or attack          │
└───────────────────────┬─────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────┐
│  SUCCESS: Creature caught! Rewards displayed            │
│  FAILURE: Creature breaks out                           │
│    - Timid: Flees                                       │
│    - Aggressive: Attacks (initiates battle)             │
│    - Curious: Waits (can throw again)                   │
└─────────────────────────────────────────────────────────┘
```

### Throwing System
```csharp
public class ThrowSystem3D : Node3D
{
    [Export] public float MinThrowForce { get; set; } = 10f;
    [Export] public float MaxThrowForce { get; set; } = 30f;
    [Export] public float ChargeRate { get; set; } = 20f;
    [Export] public float ArcPreviewSegments { get; set; } = 20;
    
    private float _currentCharge;
    private bool _isAiming;
    private Line3D _trajectoryPreview;
    private Camera3D _camera;
    
    public override void _Process(double delta)
    {
        if (Input.IsActionJustPressed("aim"))
        {
            StartAiming();
        }
        
        if (_isAiming)
        {
            if (Input.IsActionPressed("throw"))
            {
                // Charge throw
                _currentCharge = Math.Min(_currentCharge + ChargeRate * (float)delta, MaxThrowForce);
            }
            
            UpdateTrajectoryPreview();
            
            if (Input.IsActionJustReleased("throw"))
            {
                ExecuteThrow();
            }
            
            if (Input.IsActionJustPressed("cancel"))
            {
                CancelAiming();
            }
        }
    }
    
    private void UpdateTrajectoryPreview()
    {
        var points = CalculateTrajectory(GetThrowOrigin(), GetThrowDirection(), _currentCharge);
        _trajectoryPreview.Points = points;
    }
    
    private Vector3[] CalculateTrajectory(Vector3 origin, Vector3 direction, float force)
    {
        var points = new Vector3[(int)ArcPreviewSegments];
        var velocity = direction * force;
        var gravity = ProjectSettings.GetSetting("physics/3d/default_gravity").AsSingle();
        
        for (int i = 0; i < ArcPreviewSegments; i++)
        {
            float t = i * 0.1f;
            points[i] = origin + velocity * t + Vector3.Down * 0.5f * gravity * t * t;
            
            // Stop at terrain collision
            if (CheckTerrainCollision(points[i]))
                break;
        }
        
        return points;
    }
    
    private void ExecuteThrow()
    {
        var ball = PlayerData.Instance.GetSelectedBall();
        if (ball == null) return;
        
        // Spawn ball projectile
        var ballScene = ball.Model3D.Instantiate<BallProjectile3D>();
        GetTree().CurrentScene.AddChild(ballScene);
        ballScene.GlobalPosition = GetThrowOrigin();
        
        // Apply physics
        var direction = GetThrowDirection();
        ballScene.Launch(direction * _currentCharge);
        
        // Listen for hit
        ballScene.OnCreatureHit += OnBallHitCreature;
        ballScene.OnMiss += OnBallMiss;
        
        _isAiming = false;
        _currentCharge = MinThrowForce;
    }
    
    private void OnBallHitCreature(Creature3D creature, BallProjectile3D ball, HitInfo hitInfo)
    {
        var modifiers = CalculateModifiers(creature, hitInfo);
        var catchSystem = GetNode<CatchingSystem3D>("/root/CatchingSystem");
        catchSystem.AttemptCatch(creature.Data, ball.BallData, modifiers);
    }
    
    private CatchModifiers CalculateModifiers(Creature3D creature, HitInfo hitInfo)
    {
        var modifiers = new CatchModifiers();
        
        // Back strike: hit from behind
        var toCreature = (creature.GlobalPosition - hitInfo.HitPosition).Normalized();
        var creatureFacing = -creature.GlobalTransform.Basis.Z;
        float dot = toCreature.Dot(creatureFacing);
        if (dot > 0.5f) // Behind
        {
            modifiers.BackStrikeBonus = 2f;
        }
        
        // Stealth: creature was unaware
        if (!creature.HasDetectedPlayer)
        {
            modifiers.StealthBonus = 1.5f;
        }
        
        // Research bonus
        int researchLevel = PlayerData.Instance.Pokedex.GetResearchLevel(creature.Data.SpeciesId);
        modifiers.ResearchBonus = 1f + researchLevel * 0.05f; // +5% per level
        
        return modifiers;
    }
}
```

### Stealth System
```csharp
public class StealthSystem3D : Node
{
    [Export] public float BaseCrouchNoiseRadius { get; set; } = 3f;
    [Export] public float BaseWalkNoiseRadius { get; set; } = 8f;
    [Export] public float BaseRunNoiseRadius { get; set; } = 15f;
    [Export] public float GrassNoiseReduction { get; set; } = 0.5f;
    
    public float GetCurrentNoiseRadius(Player3D player)
    {
        float baseNoise = player.MovementState switch
        {
            MovementState.Crouching => BaseCrouchNoiseRadius,
            MovementState.Walking => BaseWalkNoiseRadius,
            MovementState.Running => BaseRunNoiseRadius,
            MovementState.Idle => 0f,
            _ => BaseWalkNoiseRadius
        };
        
        // Reduce noise in grass
        if (player.IsInTallGrass)
        {
            baseNoise *= GrassNoiseReduction;
        }
        
        return baseNoise;
    }
    
    public bool IsPlayerDetectable(Player3D player, Creature3D creature)
    {
        float distance = player.GlobalPosition.DistanceTo(creature.GlobalPosition);
        float noiseRadius = GetCurrentNoiseRadius(player);
        float detectionRadius = creature.DetectionRadius;
        
        // Sound detection
        if (distance < noiseRadius)
            return true;
        
        // Visual detection (line of sight)
        if (distance < detectionRadius && HasLineOfSight(creature, player))
        {
            // Check if player is in grass
            if (player.IsInTallGrass && player.MovementState == MovementState.Crouching)
                return false; // Hidden
            
            return true;
        }
        
        return false;
    }
    
    private bool HasLineOfSight(Creature3D creature, Player3D player)
    {
        var space = creature.GetWorld3D().DirectSpaceState;
        var query = PhysicsRayQueryParameters3D.Create(
            creature.GlobalPosition + Vector3.Up * 1f, // Eye level
            player.GlobalPosition + Vector3.Up * 1f
        );
        query.CollisionMask = 1; // Terrain only
        
        var result = space.IntersectRay(query);
        return result.Count == 0; // No obstruction
    }
}
```

### Creature Awareness States (3D)
```csharp
public enum AwarenessState
{
    Unaware,        // Normal behavior, catchable with stealth bonus
    Suspicious,     // Heard something, looking around
    Alert,          // Spotted player, preparing reaction
    Fleeing,        // Running away
    Aggressive      // Charging player to attack
}

public partial class Creature3D : CharacterBody3D
{
    public AwarenessState Awareness { get; private set; } = AwarenessState.Unaware;
    public bool HasDetectedPlayer => Awareness >= AwarenessState.Alert;
    
    private float _suspicionTimer;
    private float _alertTimer;
    
    public override void _Process(double delta)
    {
        var player = GetNode<Player3D>("/root/World3D/Player");
        var stealth = GetNode<StealthSystem3D>("/root/StealthSystem");
        
        bool canDetect = stealth.IsPlayerDetectable(player, this);
        
        switch (Awareness)
        {
            case AwarenessState.Unaware:
                if (canDetect)
                {
                    Awareness = AwarenessState.Suspicious;
                    _suspicionTimer = 2f;
                    PlayAnimation("suspicious");
                }
                break;
                
            case AwarenessState.Suspicious:
                _suspicionTimer -= (float)delta;
                if (canDetect)
                {
                    _suspicionTimer = 2f; // Reset timer
                    // If detected for long enough, become alert
                    if (_alertTimer < 0)
                    {
                        _alertTimer = 1f;
                    }
                    _alertTimer -= (float)delta;
                    if (_alertTimer <= 0)
                    {
                        BecomeAlert(player);
                    }
                }
                else if (_suspicionTimer <= 0)
                {
                    Awareness = AwarenessState.Unaware;
                    PlayAnimation("idle");
                }
                break;
                
            case AwarenessState.Alert:
                ReactToPlayer(player);
                break;
        }
    }
    
    private void BecomeAlert(Player3D player)
    {
        Awareness = AwarenessState.Alert;
        
        // Reaction based on behavior type
        switch (Data.Species.DefaultBehavior)
        {
            case CreatureBehavior.Timid:
                Awareness = AwarenessState.Fleeing;
                break;
            case CreatureBehavior.Aggressive:
                Awareness = AwarenessState.Aggressive;
                break;
            case CreatureBehavior.Curious:
                // Stays alert but doesn't flee or attack immediately
                break;
        }
    }
}
```

---

## Catching During Battle (3D)

When in active combat, catching works differently:

```csharp
public class BattleCatching3D : Node
{
    public void AttemptCatchInBattle(BattleCreature3D target, Item ball)
    {
        // No stealth/backstrike bonuses in battle
        var modifiers = new CatchModifiers
        {
            // Research bonus still applies
            ResearchBonus = 1f + PlayerData.Instance.Pokedex.GetResearchLevel(target.Data.SpeciesId) * 0.05f
        };
        
        var result = CaptureCalculator.AttemptCatch(target.Data, ball, modifiers);
        
        // Animate
        PlayBattleCatchAnimation(target, ball, result);
    }
    
    private async void PlayBattleCatchAnimation(BattleCreature3D target, Item ball, CatchResult result)
    {
        // Pause combat
        BattleManager3D.Instance.PauseCombat();
        
        // Ball throw at target
        await PlayThrowAnimation(target.GlobalPosition);
        
        // Creature enters ball (if hit)
        await PlayEnterBallAnimation(target);
        
        // Ball lands and shakes
        for (int i = 0; i < result.ShakeCount; i++)
        {
            await PlayShakeAnimation();
        }
        
        if (result.Success)
        {
            await PlaySuccessAnimation();
            BattleManager3D.Instance.EndBattle(BattleResultType.Caught, target.Data);
        }
        else
        {
            await PlayBreakoutAnimation(target);
            BattleManager3D.Instance.ResumeCombat();
            // Creature may be angrier now!
        }
    }
}
```

---

## Catch Feedback UI

### 3D Era HUD
```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  [Creature spotted: Pikachu Lv.15]         [!] ALERT            │
│                                                                 │
│                     ┌─────────┐                                 │
│                     │ (◉_◉)   │  ← Creature awareness icon      │
│                     │ Pikachu │                                 │
│                     └─────────┘                                 │
│                          │                                      │
│                          │  ← Throw trajectory preview          │
│                         ╱                                       │
│                        ╱                                        │
│                       ●  ← Ball aim reticle                     │
│                                                                 │
│  [Q] Crouch    [Hold LMB] Aim/Charge    [R] Switch Ball         │
│                                                                 │
│  ┌──────────────────┐                                           │
│  │ ● Poke Ball (x23)│                                           │
│  └──────────────────┘                                           │
└─────────────────────────────────────────────────────────────────┘
```

### Shake Animation Feedback
```
Shake 1: Ball wobbles... "..."
Shake 2: Ball wobbles... "..."
Shake 3: Ball wobbles... "Come on..."
Shake 4: ★ CLICK ★ "Gotcha! Pikachu was caught!"

Or if failed after 2 shakes:
Shake 1: Ball wobbles... "..."
Shake 2: Ball wobbles... BURST! "Oh no! Pikachu broke free!"
```
