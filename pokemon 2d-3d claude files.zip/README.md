# Pokemon Time Travel — Project Documentation

A creature-collecting action RPG where players travel between a retro 2D pixel-art past and a modern 3D present.

## Quick Links

### Design
- [Game Design Document](design/game-design-document.md) — Vision, pillars, scope

### Technical
- [Architecture](technical/architecture.md) — Project structure, patterns, data flow

### Systems
- [Creature System](systems/creature-system.md) — Species, stats, evolution, spawning
- [Battle System](systems/battle-system.md) — Turn-based (2D) and real-time (3D) combat
- [Catching System](systems/catching-system.md) — Capture mechanics, stealth, ball types
- [Time Travel System](systems/time-travel-system.md) — Era transitions, portals, restrictions
- [Save System](systems/save-system.md) — Persistence, slots, autosave, migration

### Engine
- [Enhancement Opportunities](engine/enhancement-opportunities.md) — Potential Godot fork improvements

---

## Getting Started

### Prerequisites
- Godot 4.x (.NET version)
- .NET 8.0 SDK
- Visual Studio Code or JetBrains Rider

### Project Setup
```bash
# Clone the repo
git clone <your-repo-url>
cd pokemon-time-travel

# Open in Godot
# 1. Launch Godot
# 2. Click "Import"
# 3. Navigate to project folder
# 4. Select project.godot
```

### Recommended Learning Path
1. Read the [Game Design Document](design/game-design-document.md)
2. Review the [Architecture](technical/architecture.md)
3. Start with Phase 1 from the GDD (vertical slice)
4. Implement systems as needed, referencing their specs

---

## Development Phases

### Phase 1: Vertical Slice ← START HERE
- [ ] Player controller (3D)
- [ ] Player controller (2D)
- [ ] One creature species (with 2D sprite + 3D model)
- [ ] Basic catching (both eras)
- [ ] Basic battle (both eras)
- [ ] Time travel transition
- [ ] Save/Load

### Phase 2: Core Loop
- [ ] 5-10 creature species
- [ ] Type effectiveness
- [ ] Pokedex/Research system
- [ ] Expanded areas
- [ ] NPCs and dialogue

### Phase 3: Content
- [ ] 20+ creatures
- [ ] Multiple areas per era
- [ ] Story implementation
- [ ] Trainer battles

### Phase 4: Polish
- [ ] Visual effects
- [ ] Audio
- [ ] UI polish
- [ ] Performance optimization

---

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Language | C# | Transferable skills, strong typing |
| Eras | Independent | Simpler than causal time travel |
| Battle (3D) | Real-time | Matches Legends Arceus feel |
| Battle (2D) | Turn-based | Nostalgic, complements 3D |

---

## Contributing

This is a learning project. Feel free to:
- Suggest improvements to the docs
- Point out issues with the design
- Share resources for learning Godot/C#

---

## Resources

### Godot
- [Godot Documentation](https://docs.godotengine.org/)
- [Godot C# Basics](https://docs.godotengine.org/en/stable/tutorials/scripting/c_sharp/c_sharp_basics.html)
- [GDQuest Tutorials](https://www.gdquest.com/)

### Pokemon Mechanics
- [Bulbapedia](https://bulbapedia.bulbagarden.net/) — Comprehensive Pokemon wiki
- [Serebii](https://serebii.net/) — Game mechanics reference

### Game Dev
- [Game Programming Patterns](https://gameprogrammingpatterns.com/) — Free book
- [Red Blob Games](https://www.redblobgames.com/) — Algorithms visualization
